// Default role-specific passwords
export const DEFAULT_PASSWORDS = {
  student: "stud123",
  teacher: "teach123",
  parent: "par123",
  admin: "admin123"
};

// Subject names
export const SUBJECTS = [
  { id: 1, name: "Physics" },
  { id: 2, name: "Chemistry" },
  { id: 3, name: "Data Structures" },
  { id: 4, name: "BEEE" },
  { id: 5, name: "Mathematics" }
];

// Attendance status colors
export const ATTENDANCE_STATUS_COLORS = {
  present: {
    bg: "bg-green-100",
    text: "text-green-800",
    border: "border-green-500",
    indicator: "bg-green-500",
    icon: "check"
  },
  absent: {
    bg: "bg-red-100",
    text: "text-red-800",
    border: "border-red-500",
    indicator: "bg-red-500",
    icon: "x"
  },
  od: {
    bg: "bg-yellow-100",
    text: "text-yellow-800",
    border: "border-yellow-500",
    indicator: "bg-yellow-500",
    icon: "clock"
  }
};

// Grade colors and classes
export const GRADE_COLORS = {
  O: {
    bg: "bg-emerald-100",
    text: "text-emerald-800",
    progress: "bg-emerald-500"
  },
  A: {
    bg: "bg-indigo-100",
    text: "text-indigo-800",
    progress: "bg-indigo-500"
  },
  B: {
    bg: "bg-blue-100",
    text: "text-blue-800",
    progress: "bg-blue-500"
  },
  C: {
    bg: "bg-orange-100",
    text: "text-orange-800",
    progress: "bg-orange-500"
  },
  F: {
    bg: "bg-red-100",
    text: "text-red-800",
    progress: "bg-red-500"
  }
};

// Navigation links for each role
export const NAVIGATION_LINKS = {
  student: [
    { href: "/", label: "Dashboard", icon: "layout-dashboard" },
    { href: "/student/performance", label: "Performance", icon: "trending-up" },
    { href: "/student/attendance", label: "Attendance", icon: "calendar-check" },
    { href: "/student/info", label: "Important Info", icon: "info" }
  ],
  teacher: [
    { href: "/teacher/dashboard", label: "Dashboard", icon: "layout-dashboard" },
    { href: "/teacher/marks", label: "Manage Marks", icon: "book" },
    { href: "/teacher/attendance", label: "Attendance", icon: "user-check" },
    { href: "/teacher/announcements", label: "Announcements", icon: "megaphone" },
    { href: "/teacher/meetings", label: "Schedule Meetings", icon: "calendar" }
  ],
  parent: [
    { href: "/parent/dashboard", label: "Dashboard", icon: "layout-dashboard" },
    { href: "/parent/performance", label: "View Performance", icon: "search" },
    { href: "/parent/meetings", label: "Meetings", icon: "calendar-days" }
  ],
  admin: [
    { href: "/admin/dashboard", label: "Dashboard", icon: "layout-dashboard" },
    { href: "/admin/students", label: "Manage Students", icon: "user-square" },
    { href: "/admin/teachers", label: "Manage Teachers", icon: "pencil-ruler" },
    { href: "/admin/settings", label: "Settings", icon: "settings" }
  ]
};
