import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Calculate grade based on marks
export function calculateGrade(marks: number): { grade: string; message: string } {
  if (marks >= 90 && marks <= 100) {
    return { 
      grade: "O", 
      message: "Excellent! Keep rocking!" 
    };
  } else if (marks >= 80 && marks < 90) {
    return { 
      grade: "A", 
      message: "Super!" 
    };
  } else if (marks >= 70 && marks < 80) {
    return { 
      grade: "B", 
      message: "Good!" 
    };
  } else if (marks >= 40 && marks < 70) {
    return { 
      grade: "C", 
      message: "Not bad! Keep trying." 
    };
  } else {
    return { 
      grade: "F", 
      message: "Need more practice." 
    };
  }
}

// Calculate attendance percentage
export function calculateAttendancePercentage(
  present: number, 
  total: number
): { percentage: number; message: string } {
  const percentage = (present / total) * 100;
  
  if (percentage < 75) {
    return {
      percentage,
      message: "Don't take leave!"
    };
  }
  
  return {
    percentage,
    message: "Good attendance!"
  };
}

// Format date for display
export function formatDate(dateString: string | Date): string {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
}

// Format time for display
export function formatTime(time: string): string {
  return time;
}

// Get the first letter of a name for avatars
export function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();
}

// Get random number between min and max
export function getRandomNumber(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Calculate overall grade from marks
export function calculateOverallGrade(marks: { marks: number; maxMarks: number }[]): {
  percentage: number;
  grade: string;
  message: string;
} {
  if (!marks.length) {
    return { percentage: 0, grade: "N/A", message: "No marks available" };
  }
  
  const totalMarks = marks.reduce((sum, mark) => sum + mark.marks, 0);
  const totalMaxMarks = marks.reduce((sum, mark) => sum + mark.maxMarks, 0);
  
  const percentage = (totalMarks / totalMaxMarks) * 100;
  const { grade, message } = calculateGrade(percentage);
  
  return { percentage, grade, message };
}
