import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Student, AttendanceStatus, InsertAttendance } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ATTENDANCE_STATUS_COLORS } from "@/lib/constants";
import { Calendar as CalendarIcon, Check, Clock, Loader2, RefreshCw, Search, X } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

export default function TeacherAttendance() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  // Fetch students
  const { data: students, isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
    enabled: !!user,
  });

  // Create attendance mutation
  const attendanceMutation = useMutation({
    mutationFn: async (data: { studentId: number; status: AttendanceStatus }) => {
      const attendanceData: InsertAttendance = {
        studentId: data.studentId,
        date: selectedDate,
        status: data.status,
        createdBy: user?.id || 0,
      };
      await apiRequest("POST", "/api/attendance", attendanceData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({
        title: "Attendance Recorded",
        description: "The student's attendance has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update attendance: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update all students' attendance mutation
  const bulkAttendanceMutation = useMutation({
    mutationFn: async () => {
      // For simplicity, we'll mark all filtered students as present
      // In a real app, you'd want to collect the statuses for each student
      const promises = filteredStudents.map((student) => {
        const attendanceData: InsertAttendance = {
          studentId: student.id,
          date: selectedDate,
          status: "present", // Default to present
          createdBy: user?.id || 0,
        };
        return apiRequest("POST", "/api/attendance", attendanceData);
      });
      await Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({
        title: "Attendance Saved",
        description: "All students' attendance has been recorded successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to save attendance: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Filter students by search query
  const filteredStudents = students?.filter(student => 
    student.user?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.studentId.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  // Get student's attendance for selected date
  const getStudentAttendance = (student: Student) => {
    if (!student.attendance) return null;
    
    const selectedDateStr = format(selectedDate, "yyyy-MM-dd");
    return student.attendance.find(a => {
      const attDate = new Date(a.date);
      return format(attDate, "yyyy-MM-dd") === selectedDateStr;
    });
  };

  // Update a student's attendance status
  const updateAttendanceStatus = (student: Student, status: AttendanceStatus) => {
    attendanceMutation.mutate({ studentId: student.id, status });
  };

  return (
    <DashboardLayout pageTitle="Manage Attendance">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Manage Attendance</h2>
        <p className="text-slate-500">Record and track student attendance</p>
      </div>

      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-end gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Select Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-[240px] justify-start text-left font-normal",
                      !selectedDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={(date) => date && setSelectedDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="flex-1">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-slate-400" />
                </div>
                <Input
                  placeholder="Search students..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <Button 
              variant="outline"
              size="icon"
              onClick={() => {
                queryClient.invalidateQueries({ queryKey: ["/api/students"] });
                setSearchQuery("");
              }}
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Student ID</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Name</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {studentsLoading ? (
                  Array(5).fill(0).map((_, index) => (
                    <tr key={index}>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-16" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-24" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-8 w-28" />
                      </td>
                    </tr>
                  ))
                ) : filteredStudents.length > 0 ? (
                  filteredStudents.map((student) => {
                    const attendance = getStudentAttendance(student);
                    const status = attendance?.status || null;
                    
                    return (
                      <tr key={student.id}>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">{student.studentId}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                          {student.user?.name || "Unknown"}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <div className="flex space-x-2">
                            <Button
                              className={`h-8 w-8 rounded-full flex items-center justify-center ${
                                status === "present" 
                                  ? "bg-green-500 text-white" 
                                  : "bg-slate-200 text-slate-400 hover:bg-green-500 hover:text-white"
                              }`}
                              variant="ghost"
                              size="icon"
                              onClick={() => updateAttendanceStatus(student, "present")}
                              disabled={attendanceMutation.isPending}
                            >
                              <Check className="h-4 w-4" />
                            </Button>
                            <Button
                              className={`h-8 w-8 rounded-full flex items-center justify-center ${
                                status === "absent" 
                                  ? "bg-red-500 text-white" 
                                  : "bg-slate-200 text-slate-400 hover:bg-red-500 hover:text-white"
                              }`}
                              variant="ghost"
                              size="icon"
                              onClick={() => updateAttendanceStatus(student, "absent")}
                              disabled={attendanceMutation.isPending}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                            <Button
                              className={`h-8 w-8 rounded-full flex items-center justify-center ${
                                status === "od" 
                                  ? "bg-yellow-500 text-white" 
                                  : "bg-slate-200 text-slate-400 hover:bg-yellow-500 hover:text-white"
                              }`}
                              variant="ghost"
                              size="icon"
                              onClick={() => updateAttendanceStatus(student, "od")}
                              disabled={attendanceMutation.isPending}
                            >
                              <Clock className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={3} className="px-4 py-3 whitespace-nowrap text-sm text-center text-slate-500">
                      {searchQuery ? "No students found matching your search" : "No students available"}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          <div className="mt-6 flex justify-between items-center">
            <div className="flex space-x-6">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-green-500 rounded-full mr-2"></div>
                <span className="text-sm text-slate-700">Present</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-red-500 rounded-full mr-2"></div>
                <span className="text-sm text-slate-700">Absent</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-yellow-500 rounded-full mr-2"></div>
                <span className="text-sm text-slate-700">OD</span>
              </div>
            </div>
            <Button 
              onClick={() => bulkAttendanceMutation.mutate()}
              disabled={bulkAttendanceMutation.isPending || filteredStudents.length === 0}
            >
              {bulkAttendanceMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Save Attendance
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold text-slate-800 mb-4">Attendance Overview</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-medium mb-3">Today's Status</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-slate-500">Present:</span>
                  <span className="text-sm font-medium">
                    {filteredStudents.filter(s => getStudentAttendance(s)?.status === "present").length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-500">Absent:</span>
                  <span className="text-sm font-medium">
                    {filteredStudents.filter(s => getStudentAttendance(s)?.status === "absent").length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-500">OD:</span>
                  <span className="text-sm font-medium">
                    {filteredStudents.filter(s => getStudentAttendance(s)?.status === "od").length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-500">Not Marked:</span>
                  <span className="text-sm font-medium">
                    {filteredStudents.filter(s => !getStudentAttendance(s)).length}
                  </span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium mb-3">Monthly Statistics</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-slate-500">Working Days:</span>
                  <span className="text-sm font-medium">22</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-500">Attendance Rate:</span>
                  <span className="text-sm font-medium">94%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-500">Average Present:</span>
                  <span className="text-sm font-medium">
                    {filteredStudents.length > 0 ? Math.floor(filteredStudents.length * 0.94) : 0}
                  </span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium mb-3">Actions</h4>
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start" size="sm">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  View Monthly Report
                </Button>
                <Button variant="outline" className="w-full justify-start" size="sm">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Reset Today's Attendance
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
