import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { StudentWithMarks, TeacherWithSubject, Meeting, InsertMeeting } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { formatDate } from "@/lib/utils";
import { Calendar as CalendarIcon, Edit, Loader2, Plus, Trash2 } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Clock } from "lucide-react";

// Form schema for meetings
const meetingSchema = z.object({
  teacherId: z.number().positive(),
  studentId: z.number().positive(),
  meetingDate: z.date(),
  startTime: z.string().min(1, "Start time is required"),
  endTime: z.string().min(1, "End time is required"),
  createdBy: z.number().positive(),
});

type MeetingFormValues = z.infer<typeof meetingSchema>;

export default function TeacherMeetings() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [currentMeeting, setCurrentMeeting] = useState<Meeting | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [meetingToDelete, setMeetingToDelete] = useState<Meeting | null>(null);

  // Fetch meetings
  const { data: meetings, isLoading } = useQuery<Meeting[]>({
    queryKey: ["/api/meetings"],
    enabled: !!user,
  });

  // Fetch students
  const { data: students } = useQuery<StudentWithMarks[]>({
    queryKey: ["/api/students"],
    enabled: !!user,
  });

  // Fetch teacher info for the current user
  const { data: teachers } = useQuery<TeacherWithSubject[]>({
    queryKey: ["/api/teachers"],
    enabled: !!user,
  });

  // Meeting form
  const form = useForm<MeetingFormValues>({
    resolver: zodResolver(meetingSchema),
    defaultValues: {
      teacherId: 0,
      studentId: 0,
      meetingDate: new Date(),
      startTime: "10:00 AM",
      endTime: "10:30 AM",
      createdBy: user?.id || 0,
    },
  });

  // Add/edit meeting mutation
  const meetingMutation = useMutation({
    mutationFn: async (values: MeetingFormValues) => {
      if (currentMeeting) {
        // Update meeting
        await apiRequest("PUT", `/api/meetings/${currentMeeting.id}`, values);
      } else {
        // Create meeting
        await apiRequest("POST", "/api/meetings", values);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meetings"] });
      setDialogOpen(false);
      toast({
        title: currentMeeting ? "Meeting Updated" : "Meeting Scheduled",
        description: currentMeeting 
          ? "The parent-teacher meeting has been updated successfully." 
          : "A new parent-teacher meeting has been scheduled successfully.",
      });
      setCurrentMeeting(null);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${currentMeeting ? "update" : "schedule"} meeting: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete meeting mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/meetings/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meetings"] });
      setDeleteDialogOpen(false);
      toast({
        title: "Meeting Deleted",
        description: "The meeting has been deleted successfully.",
      });
      setMeetingToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete meeting: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: MeetingFormValues) => {
    meetingMutation.mutate(values);
  };

  // Open dialog for creating new meeting
  const openCreateDialog = () => {
    // Find the teacher ID for the current user
    const teacherId = teachers?.find(t => t.userId === user?.id)?.id || 0;

    setCurrentMeeting(null);
    form.reset({
      teacherId,
      studentId: 0,
      meetingDate: new Date(),
      startTime: "10:00 AM",
      endTime: "10:30 AM",
      createdBy: user?.id || 0,
    });
    setDialogOpen(true);
  };

  // Open dialog for editing meeting
  const openEditDialog = (meeting: Meeting) => {
    setCurrentMeeting(meeting);
    form.reset({
      teacherId: meeting.teacherId,
      studentId: meeting.studentId,
      meetingDate: new Date(meeting.meetingDate),
      startTime: meeting.startTime,
      endTime: meeting.endTime,
      createdBy: user?.id || 0,
    });
    setDialogOpen(true);
  };

  // Open delete confirmation dialog
  const openDeleteDialog = (meeting: Meeting) => {
    setMeetingToDelete(meeting);
    setDeleteDialogOpen(true);
  };

  // Delete the meeting
  const confirmDelete = () => {
    if (meetingToDelete) {
      deleteMutation.mutate(meetingToDelete.id);
    }
  };

  // Get student name by ID
  const getStudentName = (studentId: number) => {
    const student = students?.find(s => s.id === studentId);
    return student?.user?.name || `Student #${studentId}`;
  };

  // Sort meetings by date (nearest first)
  const sortedMeetings = meetings
    ? [...meetings].sort((a, b) => new Date(a.meetingDate).getTime() - new Date(b.meetingDate).getTime())
    : [];

  // Group meetings by date
  const meetingsByDate = sortedMeetings.reduce<Record<string, Meeting[]>>((acc, meeting) => {
    const dateStr = format(new Date(meeting.meetingDate), "yyyy-MM-dd");
    if (!acc[dateStr]) {
      acc[dateStr] = [];
    }
    acc[dateStr].push(meeting);
    return acc;
  }, {});

  return (
    <DashboardLayout pageTitle="Schedule Meetings">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Parent-Teacher Meetings</h2>
          <p className="text-slate-500">Schedule and manage meetings with parents</p>
        </div>
        <Button onClick={openCreateDialog}>
          <Plus className="mr-2 h-4 w-4" />
          Schedule Meeting
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          {isLoading ? (
            <div className="space-y-6">
              {Array(3).fill(0).map((_, index) => (
                <div key={index}>
                  <Skeleton className="h-6 w-48 mb-3" />
                  <div className="space-y-4">
                    {Array(2).fill(0).map((_, i) => (
                      <div key={i} className="p-4 border rounded-md">
                        <div className="flex justify-between mb-2">
                          <Skeleton className="h-5 w-40" />
                          <div className="flex space-x-2">
                            <Skeleton className="h-8 w-8 rounded-full" />
                            <Skeleton className="h-8 w-8 rounded-full" />
                          </div>
                        </div>
                        <Skeleton className="h-4 w-24 mb-1" />
                        <Skeleton className="h-4 w-32" />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : Object.keys(meetingsByDate).length > 0 ? (
            <div className="space-y-6">
              {Object.entries(meetingsByDate).map(([dateStr, dateMeetings]) => (
                <div key={dateStr}>
                  <h3 className="text-lg font-medium mb-3">
                    {format(new Date(dateStr), "EEEE, MMMM d, yyyy")}
                  </h3>
                  <div className="space-y-4">
                    {dateMeetings.map((meeting) => (
                      <div key={meeting.id} className="p-4 border rounded-lg hover:shadow-sm transition-shadow">
                        <div className="flex justify-between">
                          <div>
                            <h4 className="font-medium">Meeting with {getStudentName(meeting.studentId)}'s Parents</h4>
                            <p className="text-sm text-slate-600">
                              Student ID: {students?.find(s => s.id === meeting.studentId)?.studentId || meeting.studentId}
                            </p>
                          </div>
                          <div className="flex space-x-2">
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="text-slate-500 hover:text-slate-700"
                              onClick={() => openEditDialog(meeting)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="text-red-500 hover:text-red-700"
                              onClick={() => openDeleteDialog(meeting)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <div className="mt-2 flex items-center text-sm text-slate-600">
                          <CalendarIcon className="mr-2 h-4 w-4 text-primary" />
                          <span>{formatDate(meeting.meetingDate)}</span>
                        </div>
                        <div className="mt-1 flex items-center text-sm text-slate-600">
                          <Clock className="mr-2 h-4 w-4 text-primary" />
                          <span>{meeting.startTime} - {meeting.endTime}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h4 className="text-xl font-medium text-slate-700 mb-2">No Meetings Scheduled</h4>
              <p className="text-slate-500 mb-6">Schedule your first parent-teacher meeting</p>
              <Button onClick={openCreateDialog}>
                <Plus className="mr-2 h-4 w-4" />
                Schedule Meeting
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Meeting Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>{currentMeeting ? "Edit Meeting" : "Schedule New Meeting"}</DialogTitle>
            <DialogDescription>
              {currentMeeting 
                ? "Update the details of your scheduled parent-teacher meeting." 
                : "Schedule a new parent-teacher meeting."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="teacherId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Teacher</FormLabel>
                    <FormControl>
                      <Select
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(parseInt(value))}
                        disabled={true} // Teacher is usually the current user
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a teacher" />
                        </SelectTrigger>
                        <SelectContent>
                          {teachers?.map((teacher) => (
                            <SelectItem key={teacher.id} value={teacher.id.toString()}>
                              {teacher.user?.name || `Teacher #${teacher.id}`}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="studentId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Student</FormLabel>
                    <FormControl>
                      <Select
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a student" />
                        </SelectTrigger>
                        <SelectContent>
                          {students?.map((student) => (
                            <SelectItem key={student.id} value={student.id.toString()}>
                              {student.user?.name || "Unknown"} ({student.studentId})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="meetingDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Meeting Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex space-x-4">
                <FormField
                  control={form.control}
                  name="startTime"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel>Start Time</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="endTime"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel>End Time</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="createdBy"
                render={({ field }) => (
                  <FormItem className="hidden">
                    <FormControl>
                      <Input type="hidden" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={meetingMutation.isPending}
                >
                  {meetingMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  {currentMeeting ? "Update" : "Schedule"} Meeting
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the meeting. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-red-500 hover:bg-red-600"
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}
