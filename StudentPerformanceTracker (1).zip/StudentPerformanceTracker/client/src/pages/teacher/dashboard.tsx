import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Student, Mark, Meeting, Announcement } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate } from "@/lib/utils";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Users, ClipboardCheck, Calendar, ArrowRight } from "lucide-react";

export default function TeacherDashboard() {
  const { user } = useAuth();

  // Fetch students
  const { data: students, isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
    enabled: !!user,
  });

  // Fetch meetings
  const { data: meetings, isLoading: meetingsLoading } = useQuery<Meeting[]>({
    queryKey: ["/api/meetings"],
    enabled: !!user,
  });

  // Fetch announcements
  const { data: announcements, isLoading: announcementsLoading } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
    enabled: !!user,
  });

  // Get pending evaluations (mock data for display)
  const pendingEvaluations = 8;

  // Get upcoming meetings
  const upcomingMeetings = meetings
    ?.filter(meeting => new Date(meeting.meetingDate) > new Date())
    .sort((a, b) => new Date(a.meetingDate).getTime() - new Date(b.meetingDate).getTime())
    .slice(0, 5) || [];

  // Get recent announcements
  const recentAnnouncements = announcements
    ?.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 3) || [];

  return (
    <DashboardLayout pageTitle="Teacher Dashboard">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">
          Welcome, {user?.name}
        </h2>
        <p className="text-slate-500">Manage your class and student performance</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Total Students</p>
                {studentsLoading ? (
                  <Skeleton className="h-10 w-16 mt-1" />
                ) : (
                  <h3 className="text-3xl font-bold text-slate-700">{students?.length || 0}</h3>
                )}
              </div>
              <div className="rounded-full p-3 bg-indigo-100">
                <Users className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Pending Evaluations</p>
                <h3 className="text-3xl font-bold text-slate-700">{pendingEvaluations}</h3>
              </div>
              <div className="rounded-full p-3 bg-amber-100">
                <ClipboardCheck className="h-5 w-5 text-amber-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Parent Meetings</p>
                {meetingsLoading ? (
                  <Skeleton className="h-10 w-16 mt-1" />
                ) : (
                  <h3 className="text-3xl font-bold text-slate-700">{upcomingMeetings.length}</h3>
                )}
              </div>
              <div className="rounded-full p-3 bg-green-100">
                <Calendar className="h-5 w-5 text-green-500" />
              </div>
            </div>
            {upcomingMeetings.length > 0 && (
              <p className="mt-4 text-sm text-slate-500">
                Next: {formatDate(upcomingMeetings[0].meetingDate)}
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold text-slate-800">Students Overview</h3>
              <Link href="/teacher/marks">
                <Button variant="ghost" size="sm" className="text-primary">
                  Manage Marks <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </Link>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Student ID</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Name</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Class</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {studentsLoading ? (
                    Array(5).fill(0).map((_, index) => (
                      <tr key={index}>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Skeleton className="h-4 w-16" />
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Skeleton className="h-4 w-24" />
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Skeleton className="h-4 w-12" />
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Skeleton className="h-4 w-20" />
                        </td>
                      </tr>
                    ))
                  ) : students && students.length > 0 ? (
                    students.slice(0, 5).map((student) => (
                      <tr key={student.id}>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">{student.studentId}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                          {student.user?.name || "Unknown"}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                          {student.classId ? `Class ${student.classId}` : "N/A"}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Active
                          </span>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={4} className="px-4 py-3 whitespace-nowrap text-sm text-center text-slate-500">
                        No students found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
            
            <div className="mt-4 flex justify-end">
              <Link href="/teacher/marks">
                <Button variant="outline" size="sm">
                  View All Students
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold text-slate-800">Upcoming Meetings</h3>
              <Link href="/teacher/meetings">
                <Button variant="ghost" size="sm" className="text-primary">
                  Schedule Meetings <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </Link>
            </div>
            
            {meetingsLoading ? (
              <div className="space-y-4">
                {Array(3).fill(0).map((_, index) => (
                  <div key={index} className="p-4 border rounded-md">
                    <div className="flex justify-between">
                      <Skeleton className="h-5 w-40" />
                      <Skeleton className="h-5 w-20" />
                    </div>
                    <Skeleton className="h-4 w-24 mt-2" />
                    <Skeleton className="h-4 w-32 mt-1" />
                  </div>
                ))}
              </div>
            ) : upcomingMeetings.length > 0 ? (
              <div className="space-y-4">
                {upcomingMeetings.map((meeting) => (
                  <div key={meeting.id} className="p-4 border rounded bg-slate-50">
                    <div className="flex justify-between">
                      <div>
                        <h4 className="font-medium">Meeting with Parent</h4>
                        <p className="text-sm text-slate-600">Student ID: {meeting.studentId}</p>
                      </div>
                      <div className="flex space-x-2">
                        <Link href={`/teacher/meetings/${meeting.id}`}>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-500 hover:text-slate-700">
                            <ArrowRight className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                    <div className="mt-2 flex items-center text-sm text-slate-600">
                      <Calendar className="mr-2 h-4 w-4 text-primary" />
                      <span>{formatDate(meeting.meetingDate)}</span>
                    </div>
                    <div className="mt-1 flex items-center text-sm text-slate-600">
                      <Clock className="mr-2 h-4 w-4 text-primary" />
                      <span>{meeting.startTime} - {meeting.endTime}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500">
                No upcoming meetings
                <div className="mt-4">
                  <Link href="/teacher/meetings">
                    <Button>Schedule Meeting</Button>
                  </Link>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-semibold text-slate-800">Recent Announcements</h3>
            <Link href="/teacher/announcements">
              <Button variant="ghost" size="sm" className="text-primary">
                Manage Announcements <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </div>
          
          {announcementsLoading ? (
            <div className="space-y-4">
              {Array(3).fill(0).map((_, index) => (
                <div key={index} className="p-4 border rounded-md">
                  <div className="flex justify-between">
                    <Skeleton className="h-5 w-40" />
                    <Skeleton className="h-5 w-20" />
                  </div>
                  <Skeleton className="h-4 w-full mt-2" />
                  <Skeleton className="h-4 w-32 mt-1" />
                </div>
              ))}
            </div>
          ) : recentAnnouncements.length > 0 ? (
            <div className="space-y-4">
              {recentAnnouncements.map((announcement) => (
                <div key={announcement.id} className="p-4 border rounded bg-slate-50">
                  <div className="flex justify-between">
                    <h4 className="font-medium">{announcement.title}</h4>
                    <div className="flex space-x-2">
                      <Link href={`/teacher/announcements/${announcement.id}`}>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-500 hover:text-slate-700">
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                  <p className="text-sm text-slate-600 mt-2">{announcement.content}</p>
                  <p className="text-xs text-slate-500 mt-2">
                    Posted {formatDate(announcement.createdAt)}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500">
              No announcements available
              <div className="mt-4">
                <Link href="/teacher/announcements">
                  <Button>Create Announcement</Button>
                </Link>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
