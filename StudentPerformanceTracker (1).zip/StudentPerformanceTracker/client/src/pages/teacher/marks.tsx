import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Student, Subject, InsertMark, Mark } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Edit, Loader2, Plus, RefreshCw, Search } from "lucide-react";

// Form schema for adding/editing marks
const markSchema = z.object({
  studentId: z.number().positive(),
  subjectId: z.number().positive(),
  marks: z.number().min(0).max(100),
  maxMarks: z.number().positive().default(100),
  assignmentMarks: z.number().min(0).max(100).optional(),
  createdBy: z.number().positive(),
});

type MarkFormValues = z.infer<typeof markSchema>;

export default function TeacherMarks() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedSubject, setSelectedSubject] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [currentMark, setCurrentMark] = useState<Mark | null>(null);

  // Fetch students
  const { data: students, isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
    enabled: !!user,
  });

  // Fetch subjects
  const { data: subjects, isLoading: subjectsLoading } = useQuery<Subject[]>({
    queryKey: ["/api/subjects"],
    enabled: !!user,
  });

  // Mark form
  const form = useForm<MarkFormValues>({
    resolver: zodResolver(markSchema),
    defaultValues: {
      marks: 0,
      maxMarks: 100,
      assignmentMarks: 0,
      createdBy: user?.id || 0,
    },
  });

  // Add/edit mark mutation
  const markMutation = useMutation({
    mutationFn: async (values: MarkFormValues) => {
      if (currentMark) {
        // Update mark
        await apiRequest("PUT", `/api/marks/${currentMark.id}`, values);
      } else {
        // Create mark
        await apiRequest("POST", "/api/marks", values);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      setDialogOpen(false);
      toast({
        title: currentMark ? "Mark Updated" : "Mark Added",
        description: currentMark 
          ? "The student's mark has been updated successfully." 
          : "A new mark has been added for the student.",
      });
      setCurrentMark(null);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${currentMark ? "update" : "add"} mark: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: MarkFormValues) => {
    markMutation.mutate(values);
  };

  // Open dialog for adding new mark
  const openAddMarkDialog = (student: Student) => {
    setCurrentMark(null);
    form.reset({
      studentId: student.id,
      subjectId: selectedSubject || 1,
      marks: 0,
      maxMarks: 100,
      assignmentMarks: 0,
      createdBy: user?.id || 0,
    });
    setDialogOpen(true);
  };

  // Open dialog for editing mark
  const openEditMarkDialog = (mark: Mark) => {
    setCurrentMark(mark);
    form.reset({
      studentId: mark.studentId,
      subjectId: mark.subjectId,
      marks: mark.marks,
      maxMarks: mark.maxMarks,
      assignmentMarks: mark.assignmentMarks || 0,
      createdBy: user?.id || 0,
    });
    setDialogOpen(true);
  };

  // Filter students by search query
  const filteredStudents = students?.filter(student => 
    student.user?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.studentId.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  // Get mark for a specific student and subject
  const getStudentMark = (student: Student, subjectId: number) => {
    return student.marks?.find(mark => mark.subjectId === subjectId);
  };

  return (
    <DashboardLayout pageTitle="Manage Marks">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Manage Student Marks</h2>
        <p className="text-slate-500">Add, edit, and view student performance marks</p>
      </div>

      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-end gap-4 mb-6">
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700 mb-1">Select Subject</label>
              {subjectsLoading ? (
                <Skeleton className="h-10 w-full" />
              ) : (
                <Select 
                  value={selectedSubject?.toString() || ""} 
                  onValueChange={(value) => setSelectedSubject(parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a subject" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects?.map((subject) => (
                      <SelectItem key={subject.id} value={subject.id.toString()}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
            <div className="flex-1">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-slate-400" />
                </div>
                <Input
                  placeholder="Search students..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <Button 
              variant="outline"
              size="icon"
              onClick={() => {
                queryClient.invalidateQueries({ queryKey: ["/api/students"] });
                queryClient.invalidateQueries({ queryKey: ["/api/subjects"] });
                setSearchQuery("");
              }}
            >
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Student ID</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Name</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Marks</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Assignment</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {studentsLoading ? (
                  Array(5).fill(0).map((_, index) => (
                    <tr key={index}>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-16" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-24" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-16" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-16" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-16" />
                      </td>
                    </tr>
                  ))
                ) : filteredStudents.length > 0 ? (
                  filteredStudents.map((student) => {
                    const mark = selectedSubject 
                      ? getStudentMark(student, selectedSubject) 
                      : null;
                    
                    return (
                      <tr key={student.id}>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">{student.studentId}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                          {student.user?.name || "Unknown"}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                          {mark ? `${mark.marks}/${mark.maxMarks}` : "Not set"}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                          {mark?.assignmentMarks ?? "Not set"}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm">
                          {mark ? (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="text-primary hover:text-indigo-800"
                              onClick={() => openEditMarkDialog(mark)}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          ) : selectedSubject ? (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="text-primary hover:text-indigo-800"
                              onClick={() => openAddMarkDialog(student)}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          ) : (
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="text-slate-400"
                              disabled
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          )}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={5} className="px-4 py-3 whitespace-nowrap text-sm text-center text-slate-500">
                      {searchQuery ? "No students found matching your search" : "No students available"}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Mark Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{currentMark ? "Edit Student Mark" : "Add Student Mark"}</DialogTitle>
            <DialogDescription>
              {currentMark 
                ? "Update the academic performance marks for this student." 
                : "Enter the academic performance marks for this student."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="studentId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Student</FormLabel>
                    <FormControl>
                      <Select
                        disabled
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a student" />
                        </SelectTrigger>
                        <SelectContent>
                          {students?.map((student) => (
                            <SelectItem key={student.id} value={student.id.toString()}>
                              {student.user?.name} ({student.studentId})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="subjectId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl>
                      <Select
                        value={field.value.toString()}
                        onValueChange={(value) => field.onChange(parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a subject" />
                        </SelectTrigger>
                        <SelectContent>
                          {subjects?.map((subject) => (
                            <SelectItem key={subject.id} value={subject.id.toString()}>
                              {subject.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="marks"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Marks</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="maxMarks"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Maximum Marks</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min={1}
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="assignmentMarks"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assignment Marks (optional)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min={0}
                        max={100}
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => {
                          const value = e.target.value;
                          field.onChange(value === "" ? undefined : parseInt(value));
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="createdBy"
                render={({ field }) => (
                  <FormItem className="hidden">
                    <FormControl>
                      <Input type="hidden" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={markMutation.isPending}
                >
                  {markMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  {currentMark ? "Update" : "Add"} Mark
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
