import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Announcement, InsertAnnouncement, Class } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { formatDate } from "@/lib/utils";
import { Edit, Loader2, Plus, Trash2 } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

// Form schema for announcements
const announcementSchema = z.object({
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
  classId: z.number().optional(),
  createdBy: z.number().positive(),
});

type AnnouncementFormValues = z.infer<typeof announcementSchema>;

export default function TeacherAnnouncements() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [currentAnnouncement, setCurrentAnnouncement] = useState<Announcement | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [announcementToDelete, setAnnouncementToDelete] = useState<Announcement | null>(null);

  // Fetch announcements
  const { data: announcements, isLoading } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
    enabled: !!user,
  });

  // Fetch classes
  const { data: classes } = useQuery<Class[]>({
    queryKey: ["/api/classes"],
    enabled: !!user,
  });

  // Announcement form
  const form = useForm<AnnouncementFormValues>({
    resolver: zodResolver(announcementSchema),
    defaultValues: {
      title: "",
      content: "",
      classId: undefined,
      createdBy: user?.id || 0,
    },
  });

  // Add/edit announcement mutation
  const announcementMutation = useMutation({
    mutationFn: async (values: AnnouncementFormValues) => {
      console.log("Submitting announcement values:", values);
      
      try {
        if (currentAnnouncement) {
          // Update announcement
          console.log("Updating announcement:", currentAnnouncement.id);
          const response = await apiRequest("PUT", `/api/announcements/${currentAnnouncement.id}`, values);
          console.log("Update response:", response);
          return response;
        } else {
          // Create announcement
          console.log("Creating new announcement");
          const response = await apiRequest("POST", "/api/announcements", values);
          console.log("Create response:", response);
          return response;
        }
      } catch (err) {
        console.error("Error during announcement mutation:", err);
        throw err;
      }
    },
    onSuccess: (data) => {
      console.log("Announcement mutation successful, data:", data);
      queryClient.invalidateQueries({ queryKey: ["/api/announcements"] });
      setDialogOpen(false);
      toast({
        title: currentAnnouncement ? "Announcement Updated" : "Announcement Created",
        description: currentAnnouncement 
          ? "The announcement has been updated successfully." 
          : "A new announcement has been created successfully.",
      });
      setCurrentAnnouncement(null);
      form.reset();
    },
    onError: (error) => {
      console.error("Announcement mutation error:", error);
      toast({
        title: "Error",
        description: `Failed to ${currentAnnouncement ? "update" : "create"} announcement: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete announcement mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/announcements/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/announcements"] });
      setDeleteDialogOpen(false);
      toast({
        title: "Announcement Deleted",
        description: "The announcement has been deleted successfully.",
      });
      setAnnouncementToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete announcement: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: AnnouncementFormValues) => {
    announcementMutation.mutate(values);
  };

  // Open dialog for creating new announcement
  const openCreateDialog = () => {
    setCurrentAnnouncement(null);
    form.reset({
      title: "",
      content: "",
      classId: undefined,
      createdBy: user?.id || 0,
    });
    setDialogOpen(true);
  };

  // Open dialog for editing announcement
  const openEditDialog = (announcement: Announcement) => {
    setCurrentAnnouncement(announcement);
    form.reset({
      title: announcement.title,
      content: announcement.content,
      classId: announcement.classId || undefined,
      createdBy: user?.id || 0,
    });
    setDialogOpen(true);
  };

  // Open delete confirmation dialog
  const openDeleteDialog = (announcement: Announcement) => {
    setAnnouncementToDelete(announcement);
    setDeleteDialogOpen(true);
  };

  // Delete the announcement
  const confirmDelete = () => {
    if (announcementToDelete) {
      deleteMutation.mutate(announcementToDelete.id);
    }
  };

  // Sort announcements by date (newest first)
  const sortedAnnouncements = announcements
    ? [...announcements].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    : [];

  return (
    <DashboardLayout pageTitle="Announcements">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Manage Announcements</h2>
          <p className="text-slate-500">Create and manage important announcements for students</p>
        </div>
        <Button onClick={openCreateDialog}>
          <Plus className="mr-2 h-4 w-4" />
          New Announcement
        </Button>
      </div>

      <Card>
        <CardContent className="p-6">
          {isLoading ? (
            <div className="space-y-4">
              {Array(3).fill(0).map((_, index) => (
                <div key={index} className="p-4 border rounded-md">
                  <div className="flex justify-between mb-2">
                    <Skeleton className="h-6 w-1/3" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <div className="flex justify-between items-center mt-4">
                    <Skeleton className="h-4 w-32" />
                    <div className="flex space-x-2">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-8 w-8 rounded-full" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : sortedAnnouncements.length > 0 ? (
            <div className="space-y-4">
              {sortedAnnouncements.map((announcement) => (
                <div key={announcement.id} className="p-4 border rounded-lg hover:shadow-sm transition-shadow">
                  <div className="flex justify-between">
                    <h4 className="font-medium text-base">{announcement.title}</h4>
                    <div className="flex space-x-2">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-slate-500 hover:text-slate-700"
                        onClick={() => openEditDialog(announcement)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-red-500 hover:text-red-700"
                        onClick={() => openDeleteDialog(announcement)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <p className="text-sm text-slate-600 mt-2 whitespace-pre-line">{announcement.content}</p>
                  <div className="mt-3 flex justify-between items-center">
                    <p className="text-xs text-slate-500">
                      Posted {formatDate(announcement.createdAt)}
                      {announcement.classId && (
                        <span className="ml-2 px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full text-xs">
                          Class {classes?.find(c => c.id === announcement.classId)?.name || announcement.classId}
                        </span>
                      )}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <h4 className="text-xl font-medium text-slate-700 mb-2">No Announcements Yet</h4>
              <p className="text-slate-500 mb-6">Create your first announcement to keep students informed</p>
              <Button onClick={openCreateDialog}>
                <Plus className="mr-2 h-4 w-4" />
                New Announcement
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Announcement Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>{currentAnnouncement ? "Edit Announcement" : "Create New Announcement"}</DialogTitle>
            <DialogDescription>
              {currentAnnouncement 
                ? "Update the details of your existing announcement." 
                : "Create a new announcement to share important information."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter announcement title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Enter announcement details" 
                        className="min-h-[120px]" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="classId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Class (Optional)</FormLabel>
                    <FormControl>
                      <Select
                        value={field.value?.toString() || "0"}
                        onValueChange={(value) => 
                          field.onChange(value !== "0" ? parseInt(value) : undefined)
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select a class (or leave empty for all)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">All Classes</SelectItem>
                          {classes?.map((cls) => (
                            <SelectItem key={cls.id} value={cls.id.toString() || "none"}>
                              {cls.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="createdBy"
                render={({ field }) => (
                  <FormItem className="hidden">
                    <FormControl>
                      <Input type="hidden" {...field} />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={announcementMutation.isPending}
                >
                  {announcementMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  {currentAnnouncement ? "Update" : "Create"} Announcement
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the announcement. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-red-500 hover:bg-red-600"
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}
