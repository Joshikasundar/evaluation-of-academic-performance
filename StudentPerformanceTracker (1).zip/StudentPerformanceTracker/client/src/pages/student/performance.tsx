import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { MarkWithSubject } from "@shared/schema";
import { calculateGrade } from "@/lib/utils";
import { GRADE_COLORS } from "@/lib/constants";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Chart,
  ChartLegend,
  ChartBar,
  ChartContainer,
  ChartAxisX,
  ChartAxisY,
  ChartContent
} from "@/components/ui/chart";

export default function StudentPerformance() {
  const { user } = useAuth();

  // Fetch student marks
  const { data: marks, isLoading: marksLoading } = useQuery<MarkWithSubject[]>({
    queryKey: [`/api/students/${user?.id}/marks`],
    enabled: !!user,
  });

  // Calculate overall statistics
  const totalMarks = marks?.reduce((sum, mark) => sum + mark.marks, 0) || 0;
  const totalMaxMarks = marks?.reduce((sum, mark) => sum + mark.maxMarks, 0) || 0;
  const overallPercentage = totalMaxMarks > 0 ? (totalMarks / totalMaxMarks) * 100 : 0;

  // Calculate statistics for each subject
  const subjectPerformance = marks?.map((mark) => {
    const percentage = (mark.marks / mark.maxMarks) * 100;
    const { grade, message } = calculateGrade(percentage);
    return {
      ...mark,
      percentage,
      grade,
      message,
      color: GRADE_COLORS[grade as keyof typeof GRADE_COLORS]
    };
  }) || [];

  return (
    <DashboardLayout pageTitle="Academic Performance">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Performance Report</h2>
        <p className="text-slate-500">View your academic performance across all subjects</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="col-span-1 lg:col-span-2">
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold text-slate-800 mb-4">Overall Performance</h3>
            {marksLoading ? (
              <Skeleton className="h-60 w-full" />
            ) : marks && marks.length > 0 ? (
              <Chart className="w-full aspect-[4/3]">
                <ChartContainer>
                  <ChartContent>
                    {subjectPerformance.map((subject, i) => (
                      <ChartBar 
                        key={subject.id}
                        value={subject.percentage} 
                        name={subject.subject.name}
                        color={`var(--chart-${(i % 5) + 1})`}
                      />
                    ))}
                  </ChartContent>
                  <ChartAxisX />
                  <ChartAxisY />
                </ChartContainer>
                <ChartLegend />
              </Chart>
            ) : (
              <div className="flex items-center justify-center h-60 text-slate-500">
                No performance data available
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold text-slate-800 mb-4">Overall Score</h3>
            {marksLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-32 w-32 rounded-full mx-auto" />
                <Skeleton className="h-6 w-3/4 mx-auto" />
                <Skeleton className="h-4 w-1/2 mx-auto" />
              </div>
            ) : marks && marks.length > 0 ? (
              <div className="flex flex-col items-center">
                <div className="relative h-32 w-32">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-4xl font-bold text-primary">{Math.round(overallPercentage)}%</span>
                  </div>
                  <svg className="w-full h-full" viewBox="0 0 100 100">
                    <circle
                      className="text-slate-200"
                      strokeWidth="10"
                      stroke="currentColor"
                      fill="transparent"
                      r="40"
                      cx="50"
                      cy="50"
                    />
                    <circle
                      className="text-primary"
                      strokeWidth="10"
                      strokeDasharray={`${(overallPercentage / 100) * 251.2} 251.2`}
                      strokeLinecap="round"
                      stroke="currentColor"
                      fill="transparent"
                      r="40"
                      cx="50"
                      cy="50"
                    />
                  </svg>
                </div>
                <h4 className="text-xl font-semibold mt-4">{calculateGrade(overallPercentage).grade} Grade</h4>
                <p className="text-slate-500 mt-2">{calculateGrade(overallPercentage).message}</p>
              </div>
            ) : (
              <div className="flex items-center justify-center h-60 text-slate-500">
                No score data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold text-slate-800 mb-4">Subject-wise Performance</h3>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Subject</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Marks</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Assignment</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Total</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Grade</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Feedback</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {marksLoading ? (
                  Array(5).fill(0).map((_, index) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Skeleton className="h-4 w-24" />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Skeleton className="h-4 w-16" />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Skeleton className="h-4 w-16" />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Skeleton className="h-4 w-16" />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Skeleton className="h-4 w-8" />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Skeleton className="h-4 w-24" />
                      </td>
                    </tr>
                  ))
                ) : marks && marks.length > 0 ? (
                  subjectPerformance.map((subject) => {
                    const total = subject.assignmentMarks ? (subject.marks + subject.assignmentMarks) / 2 : subject.marks;
                    const percentage = (total / subject.maxMarks) * 100;
                    const { grade, message } = calculateGrade(percentage);
                    const gradeColor = GRADE_COLORS[grade as keyof typeof GRADE_COLORS];
                    
                    return (
                      <tr key={subject.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-slate-900">{subject.subject.name}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-slate-900">{subject.marks}/{subject.maxMarks}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-slate-900">{subject.assignmentMarks || "N/A"}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-slate-900">{Math.round(percentage)}%</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${gradeColor.bg} ${gradeColor.text}`}>
                            {grade}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                          "{message}"
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-4 text-center text-sm text-slate-500">
                      No performance data available
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
