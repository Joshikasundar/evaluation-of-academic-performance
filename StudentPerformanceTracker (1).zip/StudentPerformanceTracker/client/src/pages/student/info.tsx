import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Announcement } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate } from "@/lib/utils";
import { Bell, Info, CalendarClock, AlertCircle } from "lucide-react";

export default function StudentInfo() {
  const { user } = useAuth();

  // Fetch announcements
  const { data: announcements, isLoading } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
    enabled: !!user,
  });

  // Group announcements by type (for display purposes)
  const announcementsByType = announcements?.reduce<Record<string, Announcement[]>>(
    (acc, announcement) => {
      const type = announcement.title.toLowerCase().includes("exam") 
        ? "exams" 
        : announcement.title.toLowerCase().includes("assignment") 
          ? "assignments" 
          : "general";
      
      if (!acc[type]) {
        acc[type] = [];
      }
      acc[type].push(announcement);
      return acc;
    },
    {}
  ) || {};

  const getIconByType = (type: string) => {
    switch (type) {
      case "assignments":
        return <Bell className="h-5 w-5 text-amber-500" />;
      case "exams":
        return <CalendarClock className="h-5 w-5 text-primary" />;
      case "general":
        return <Info className="h-5 w-5 text-green-500" />;
      default:
        return <AlertCircle className="h-5 w-5 text-slate-500" />;
    }
  };

  const getColorsByType = (type: string) => {
    switch (type) {
      case "assignments":
        return {
          border: "border-amber-500",
          bg: "bg-amber-50",
          heading: "text-amber-800",
          text: "text-amber-700",
          meta: "text-amber-500"
        };
      case "exams":
        return {
          border: "border-primary",
          bg: "bg-indigo-50",
          heading: "text-indigo-800",
          text: "text-indigo-700",
          meta: "text-indigo-500"
        };
      case "general":
        return {
          border: "border-green-500",
          bg: "bg-green-50",
          heading: "text-green-800",
          text: "text-green-700",
          meta: "text-green-500"
        };
      default:
        return {
          border: "border-slate-300",
          bg: "bg-slate-50",
          heading: "text-slate-800",
          text: "text-slate-700",
          meta: "text-slate-500"
        };
    }
  };

  return (
    <DashboardLayout pageTitle="Important Information">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Important Information</h2>
        <p className="text-slate-500">Stay updated with announcements, assignments, and important dates</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-semibold flex items-center">
              <Bell className="h-5 w-5 mr-2 text-amber-500" />
              Assignments
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {Array(3).fill(0).map((_, i) => (
                  <div key={i} className="p-4 border rounded-md">
                    <Skeleton className="h-5 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ))}
              </div>
            ) : announcementsByType.assignments?.length ? (
              <div className="space-y-4">
                {announcementsByType.assignments.map((announcement) => {
                  const colors = getColorsByType("assignments");
                  return (
                    <div key={announcement.id} className={`p-4 border-l-4 ${colors.border} ${colors.bg} rounded`}>
                      <h3 className={`text-sm font-medium ${colors.heading}`}>{announcement.title}</h3>
                      <div className={`mt-1 text-sm ${colors.text}`}>
                        <p>{announcement.content}</p>
                      </div>
                      <p className={`text-xs ${colors.meta} mt-2`}>
                        Posted {formatDate(announcement.createdAt)}
                      </p>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500">
                No pending assignments
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-semibold flex items-center">
              <CalendarClock className="h-5 w-5 mr-2 text-primary" />
              Exams & Tests
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {Array(3).fill(0).map((_, i) => (
                  <div key={i} className="p-4 border rounded-md">
                    <Skeleton className="h-5 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ))}
              </div>
            ) : announcementsByType.exams?.length ? (
              <div className="space-y-4">
                {announcementsByType.exams.map((announcement) => {
                  const colors = getColorsByType("exams");
                  return (
                    <div key={announcement.id} className={`p-4 border-l-4 ${colors.border} ${colors.bg} rounded`}>
                      <h3 className={`text-sm font-medium ${colors.heading}`}>{announcement.title}</h3>
                      <div className={`mt-1 text-sm ${colors.text}`}>
                        <p>{announcement.content}</p>
                      </div>
                      <p className={`text-xs ${colors.meta} mt-2`}>
                        Posted {formatDate(announcement.createdAt)}
                      </p>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500">
                No upcoming exams
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-lg font-semibold flex items-center">
              <Info className="h-5 w-5 mr-2 text-green-500" />
              General Announcements
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {Array(3).fill(0).map((_, i) => (
                  <div key={i} className="p-4 border rounded-md">
                    <Skeleton className="h-5 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-1" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ))}
              </div>
            ) : announcementsByType.general?.length ? (
              <div className="space-y-4">
                {announcementsByType.general.map((announcement) => {
                  const colors = getColorsByType("general");
                  return (
                    <div key={announcement.id} className={`p-4 border-l-4 ${colors.border} ${colors.bg} rounded`}>
                      <h3 className={`text-sm font-medium ${colors.heading}`}>{announcement.title}</h3>
                      <div className={`mt-1 text-sm ${colors.text}`}>
                        <p>{announcement.content}</p>
                      </div>
                      <p className={`text-xs ${colors.meta} mt-2`}>
                        Posted {formatDate(announcement.createdAt)}
                      </p>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-500">
                No general announcements
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Announcements</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {Array(5).fill(0).map((_, i) => (
                <div key={i} className="p-4 border rounded-md">
                  <Skeleton className="h-5 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-1" />
                  <Skeleton className="h-4 w-full mb-1" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              ))}
            </div>
          ) : announcements && announcements.length > 0 ? (
            <div className="space-y-4">
              {announcements.map((announcement) => {
                // Determine the type based on the title
                const type = announcement.title.toLowerCase().includes("exam") 
                  ? "exams" 
                  : announcement.title.toLowerCase().includes("assignment") 
                    ? "assignments" 
                    : "general";
                
                const colors = getColorsByType(type);
                const icon = getIconByType(type);
                
                return (
                  <div key={announcement.id} className="p-4 border rounded-lg">
                    <div className="flex">
                      <div className="flex-shrink-0 mt-1">
                        {icon}
                      </div>
                      <div className="ml-3 flex-1">
                        <div className="flex justify-between">
                          <h3 className="text-base font-medium text-slate-900">{announcement.title}</h3>
                          <span className={`px-2 py-1 text-xs rounded-full ${colors.bg} ${colors.heading}`}>
                            {type.charAt(0).toUpperCase() + type.slice(1)}
                          </span>
                        </div>
                        <div className="mt-2 text-sm text-slate-700">
                          <p>{announcement.content}</p>
                        </div>
                        <div className="mt-2 text-xs text-slate-500">
                          Posted on {formatDate(announcement.createdAt)}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500">
              No announcements available
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
