import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Attendance, AttendanceStatus } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDate } from "@/lib/utils";
import { ATTENDANCE_STATUS_COLORS } from "@/lib/constants";
import { 
  Check, 
  X, 
  Clock,
} from "lucide-react";

export default function StudentAttendance() {
  const { user } = useAuth();

  // Fetch student attendance
  const { data: attendance, isLoading } = useQuery<Attendance[]>({
    queryKey: [`/api/students/${user?.id}/attendance`],
    enabled: !!user,
  });

  // Calculate attendance statistics
  const totalDays = attendance?.length || 0;
  const presentDays = attendance?.filter(a => a.status === "present").length || 0;
  const absentDays = attendance?.filter(a => a.status === "absent").length || 0;
  const odDays = attendance?.filter(a => a.status === "od").length || 0;
  
  const attendancePercentage = totalDays > 0 
    ? Math.round((presentDays / totalDays) * 100) 
    : 0;

  // Group attendance by month
  const monthlyAttendance = attendance?.reduce<Record<string, Attendance[]>>((acc, record) => {
    const month = new Date(record.date).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    if (!acc[month]) {
      acc[month] = [];
    }
    acc[month].push(record);
    return acc;
  }, {}) || {};

  // Sort attendance records by date (newest first)
  Object.keys(monthlyAttendance).forEach(month => {
    monthlyAttendance[month].sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  });

  const getStatusIcon = (status: AttendanceStatus) => {
    switch (status) {
      case "present":
        return <Check className="h-4 w-4" />;
      case "absent":
        return <X className="h-4 w-4" />;
      case "od":
        return <Clock className="h-4 w-4" />;
    }
  };

  return (
    <DashboardLayout pageTitle="Attendance">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Attendance Report</h2>
        <p className="text-slate-500">View your attendance records and statistics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Overall Attendance</p>
                {isLoading ? (
                  <Skeleton className="h-10 w-16 mt-1" />
                ) : (
                  <h3 className="text-3xl font-bold text-slate-700">{attendancePercentage}%</h3>
                )}
              </div>
              <span className={`bg-${attendancePercentage >= 75 ? 'green' : 'amber'}-100 text-${attendancePercentage >= 75 ? 'green' : 'amber'}-600 text-xs px-3 py-1 rounded-full`}>
                {attendancePercentage >= 75 ? 'Good' : 'Warning'}
              </span>
            </div>
            <div className="mt-4">
              {isLoading ? (
                <Skeleton className="h-2 w-full" />
              ) : (
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div 
                    className={`bg-${attendancePercentage >= 75 ? 'green' : 'amber'}-500 h-2 rounded-full`}
                    style={{ width: `${attendancePercentage}%` }}
                  ></div>
                </div>
              )}
            </div>
            {attendancePercentage < 75 && (
              <p className="mt-4 text-sm text-red-500">
                Warning: Your attendance is below 75%. Don't take leave!
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <p className="text-slate-500 text-sm mb-2">Attendance Breakdown</p>
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm">Present</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-sm font-medium">{presentDays} days</span>
                    <span className="text-xs text-slate-500 ml-1">({Math.round((presentDays / totalDays) * 100) || 0}%)</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                    <span className="text-sm">Absent</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-sm font-medium">{absentDays} days</span>
                    <span className="text-xs text-slate-500 ml-1">({Math.round((absentDays / totalDays) * 100) || 0}%)</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                    <span className="text-sm">OD</span>
                  </div>
                  <div className="flex items-center">
                    <span className="text-sm font-medium">{odDays} days</span>
                    <span className="text-xs text-slate-500 ml-1">({Math.round((odDays / totalDays) * 100) || 0}%)</span>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <p className="text-slate-500 text-sm mb-2">Current Month</p>
            {isLoading ? (
              <div className="grid grid-cols-7 gap-2">
                {Array(14).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-7 gap-2">
                {/* Day labels */}
                {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
                  <div key={i} className="h-8 flex items-center justify-center text-xs font-medium text-slate-500">
                    {day}
                  </div>
                ))}
                
                {/* Calendar days - simplified version for demo */}
                {Array(28).fill(0).map((_, i) => {
                  const day = i + 1;
                  const today = new Date();
                  const isCurrentMonth = day <= today.getDate();
                  const status = isCurrentMonth ? ['present', 'absent', 'od', 'present'][i % 4] as AttendanceStatus : null;
                  
                  return (
                    <div 
                      key={i}
                      className={`h-10 flex items-center justify-center rounded border text-sm font-medium ${
                        status 
                          ? `${ATTENDANCE_STATUS_COLORS[status].bg} ${ATTENDANCE_STATUS_COLORS[status].text} border-${ATTENDANCE_STATUS_COLORS[status].border}`
                          : ''
                      }`}
                    >
                      {day}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold text-slate-800 mb-4">Attendance History</h3>
          
          {isLoading ? (
            <div className="space-y-6">
              {Array(3).fill(0).map((_, i) => (
                <div key={i}>
                  <Skeleton className="h-6 w-48 mb-3" />
                  <div className="space-y-2">
                    {Array(5).fill(0).map((_, j) => (
                      <Skeleton key={j} className="h-12 w-full" />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : Object.keys(monthlyAttendance).length > 0 ? (
            <div className="space-y-6">
              {Object.entries(monthlyAttendance).map(([month, records]) => (
                <div key={month} className="border rounded-lg overflow-hidden">
                  <div className="bg-slate-50 py-3 px-4 font-medium">
                    {month}
                  </div>
                  <div className="divide-y">
                    {records.map((record) => {
                      const status = record.status;
                      const statusColors = ATTENDANCE_STATUS_COLORS[status];
                      
                      return (
                        <div key={record.id} className="flex items-center justify-between p-4">
                          <div className="flex items-center">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${statusColors.indicator} text-white mr-3`}>
                              {getStatusIcon(status)}
                            </div>
                            <div>
                              <p className="font-medium">{formatDate(record.date)}</p>
                              <p className="text-sm text-slate-500">
                                {new Date(record.date).toLocaleDateString("en-US", { weekday: "long" })}
                              </p>
                            </div>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${statusColors.bg} ${statusColors.text}`}>
                            {status.charAt(0).toUpperCase() + status.slice(1)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-500">
              No attendance records available
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
