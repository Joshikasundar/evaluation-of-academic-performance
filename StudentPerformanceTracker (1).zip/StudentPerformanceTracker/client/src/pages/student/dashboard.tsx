import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Mark, MarkWithSubject, Attendance, Announcement, Student } from "@shared/schema";
import { calculateOverallGrade, calculateGrade, formatDate } from "@/lib/utils";
import { GRADE_COLORS } from "@/lib/constants";
import { Bell, InfoIcon } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function StudentDashboard() {
  const { user } = useAuth();
  
  // Debugging information about login status
  console.log("User authenticated:", user ? "Yes" : "No");
  if (user) {
    console.log("User details:", { id: user.id, name: user.name, role: user.role });
  }

  // Fetch student profile only if user exists and is a student
  const { data: studentProfile, isLoading: profileLoading, error: profileError } = useQuery<Student>({
    queryKey: [`/api/students/user/${user?.id}`],
    enabled: !!user && user.role === "student",
  });
  
  // Log student profile data for debugging
  console.log("Student profile:", studentProfile);
  if (profileError) console.error("Profile error:", profileError);

  // Fetch student marks only if student profile is loaded
  const { data: marks = [], isLoading: marksLoading, error: marksError } = useQuery<MarkWithSubject[]>({
    queryKey: [`/api/students/${studentProfile?.id}/marks`],
    enabled: !!studentProfile?.id,
    staleTime: 60000, // Cache for 1 minute
  });
  
  // Log marks data for debugging
  console.log("Marks:", marks);
  if (marksError) console.error("Marks error:", marksError);

  // Fetch student attendance only if student profile is loaded
  const { data: attendance = [], isLoading: attendanceLoading, error: attendanceError } = useQuery<Attendance[]>({
    queryKey: [`/api/students/${studentProfile?.id}/attendance`],
    enabled: !!studentProfile?.id,
    staleTime: 60000, // Cache for 1 minute
  });
  
  // Log attendance data for debugging
  console.log("Attendance:", attendance);
  if (attendanceError) console.error("Attendance error:", attendanceError);

  // Fetch announcements
  const { data: announcements, isLoading: announcementsLoading, error: announcementsError } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
    enabled: !!user,
  });
  
  // Log announcements data for debugging
  console.log("Announcements:", announcements);
  if (announcementsError) console.error("Announcements error:", announcementsError);

  // Calculate overall grade
  const overallGrade = marks 
    ? calculateOverallGrade(marks)
    : { percentage: 0, grade: "N/A", message: "No marks available" };

  // Calculate attendance percentage
  const attendanceCount = attendance?.length ?? 0;
  const presentCount = attendance?.filter(a => a.status === "present").length ?? 0;
  const attendancePercentage = attendanceCount > 0 
    ? Math.round((presentCount / attendanceCount) * 100) 
    : 0;

  // Get latest 4 attendance records
  const recentAttendance = attendance 
    ? [...attendance].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 4)
    : [];

  // Get grade colors
  const gradeColor = overallGrade.grade !== "N/A" 
    ? GRADE_COLORS[overallGrade.grade as keyof typeof GRADE_COLORS] 
    : GRADE_COLORS.C;

  return (
    <DashboardLayout pageTitle="Dashboard">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">
          Welcome, {user?.name}
        </h2>
        <p className="text-slate-500">Here's your academic performance summary</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
        {/* Overall Grade Card */}
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Overall Grade</p>
                {marksLoading ? (
                  <Skeleton className="h-10 w-10 mt-1" />
                ) : (
                  <h3 className="text-3xl font-bold text-emerald-500">{overallGrade.grade}</h3>
                )}
              </div>
              <span className={`${gradeColor.bg} ${gradeColor.text} text-xs px-3 py-1 rounded-full`}>
                {overallGrade.grade === "N/A" ? "Not Available" : "Excellent"}
              </span>
            </div>
            <p className="mt-4 text-sm text-slate-600">"{overallGrade.message}"</p>
          </CardContent>
        </Card>

        {/* Overall Score Card */}
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Overall Score</p>
                {marksLoading ? (
                  <Skeleton className="h-10 w-16 mt-1" />
                ) : (
                  <h3 className="text-3xl font-bold text-primary">{Math.round(overallGrade.percentage)}%</h3>
                )}
              </div>
            </div>
            <div className="mt-4">
              {marksLoading ? (
                <Skeleton className="h-2 w-full" />
              ) : (
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div 
                    className="bg-primary h-2 rounded-full" 
                    style={{ width: `${Math.round(overallGrade.percentage)}%` }}
                  ></div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Attendance Card */}
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Attendance</p>
                {attendanceLoading ? (
                  <Skeleton className="h-10 w-16 mt-1" />
                ) : (
                  <h3 className="text-3xl font-bold text-slate-700">{attendancePercentage}%</h3>
                )}
              </div>
              <span className={`bg-green-100 text-green-600 text-xs px-3 py-1 rounded-full`}>
                {attendancePercentage < 75 ? "Warning" : "Good"}
              </span>
            </div>
            <div className="mt-4">
              {attendanceLoading ? (
                <Skeleton className="h-2 w-full" />
              ) : (
                <div className="w-full bg-slate-200 rounded-full h-2">
                  <div 
                    className="bg-green-500 h-2 rounded-full" 
                    style={{ width: `${attendancePercentage}%` }}
                  ></div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Pending Assignments Card */}
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Pending Assignments</p>
                <h3 className="text-3xl font-bold text-slate-700">2</h3>
              </div>
            </div>
            <p className="mt-4 text-sm text-amber-500">Due in 3 days</p>
          </CardContent>
        </Card>
      </div>

      <div className="mb-8">
        <h3 className="text-xl font-semibold text-slate-800 mb-4">Subject Performance</h3>
        <Card>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Subject</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Marks</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Grade</th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Performance</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {marksLoading ? (
                  Array(5).fill(0).map((_, index) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Skeleton className="h-4 w-24" />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Skeleton className="h-4 w-16" />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Skeleton className="h-4 w-8" />
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <Skeleton className="h-2 w-full" />
                      </td>
                    </tr>
                  ))
                ) : marks && marks.length > 0 ? (
                  marks.map((mark) => {
                    const { grade } = calculateGrade(mark.marks);
                    const gradeColor = GRADE_COLORS[grade as keyof typeof GRADE_COLORS];
                    
                    return (
                      <tr key={mark.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-slate-900">
                            {mark.subject.name}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-slate-900">
                            {mark.marks}/{mark.maxMarks}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${gradeColor.bg} ${gradeColor.text}`}>
                            {grade}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                          <div className="w-full bg-slate-200 rounded-full h-2">
                            <div 
                              className={`${gradeColor.progress} h-2 rounded-full`} 
                              style={{ width: `${(mark.marks / mark.maxMarks) * 100}%` }}
                            ></div>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={4} className="px-6 py-4 text-center text-sm text-slate-500">
                      No marks available
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Attendance */}
        <Card>
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold text-slate-800 mb-4">Recent Attendance</h3>
            <div className="space-y-4">
              {attendanceLoading ? (
                Array(4).fill(0).map((_, index) => (
                  <div key={index} className="flex items-center justify-between border-b pb-3">
                    <Skeleton className="h-12 w-32" />
                    <Skeleton className="h-8 w-20" />
                  </div>
                ))
              ) : recentAttendance.length > 0 ? (
                recentAttendance.map((record, index) => (
                  <div key={index} className="flex items-center justify-between border-b pb-3 last:border-b-0">
                    <div>
                      <p className="font-medium">{formatDate(record.date)}</p>
                      <p className="text-sm text-slate-500">
                        {new Date(record.date).toLocaleDateString("en-US", { weekday: "long" })}
                      </p>
                    </div>
                    <span 
                      className={`px-3 py-1 rounded-full text-sm font-medium ${
                        record.status === "present" 
                          ? "bg-green-100 text-green-800" 
                          : record.status === "absent" 
                            ? "bg-red-100 text-red-800" 
                            : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                    </span>
                  </div>
                ))
              ) : (
                <div className="text-center text-sm text-slate-500 py-4">
                  No attendance records available
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Important Information */}
        <Card>
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold text-slate-800 mb-4">Important Information</h3>
            <div className="space-y-4">
              {announcementsLoading ? (
                Array(2).fill(0).map((_, index) => (
                  <div key={index} className="p-4 border-l-4 border-amber-500 bg-amber-50 rounded">
                    <div className="flex">
                      <Skeleton className="h-4 w-4" />
                      <div className="ml-3 w-full">
                        <Skeleton className="h-4 w-1/3 mb-2" />
                        <Skeleton className="h-3 w-full mb-1" />
                        <Skeleton className="h-3 w-2/3" />
                      </div>
                    </div>
                  </div>
                ))
              ) : announcements && announcements.length > 0 ? (
                announcements.map((announcement, index) => (
                  <div key={index} className={`p-4 border-l-4 ${
                    index % 2 === 0 
                      ? "border-amber-500 bg-amber-50" 
                      : "border-primary bg-indigo-50"
                  } rounded`}>
                    <div className="flex">
                      <div className="flex-shrink-0">
                        {index % 2 === 0 ? (
                          <Bell className="text-amber-500" size={16} />
                        ) : (
                          <InfoIcon className="text-primary" size={16} />
                        )}
                      </div>
                      <div className="ml-3">
                        <h3 className={`text-sm font-medium ${
                          index % 2 === 0 ? "text-amber-800" : "text-indigo-800"
                        }`}>
                          {announcement.title}
                        </h3>
                        <div className={`mt-1 text-sm ${
                          index % 2 === 0 ? "text-amber-700" : "text-indigo-700"
                        }`}>
                          <p>{announcement.content}</p>
                        </div>
                        <p className={`text-xs ${
                          index % 2 === 0 ? "text-amber-500" : "text-indigo-500"
                        } mt-2`}>
                          Posted {formatDate(announcement.createdAt)}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-sm text-slate-500 py-4">
                  No announcements available
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
