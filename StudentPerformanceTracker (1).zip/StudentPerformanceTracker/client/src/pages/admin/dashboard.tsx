import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Student, Teacher, Class } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { 
  Chart,
  ChartLegend,
  ChartBar,
  ChartContainer,
  ChartAxisX,
  ChartAxisY,
  ChartContent
} from "@/components/ui/chart";
import { ArrowRight, School, UserSquare, Presentation } from "lucide-react";
import { Link } from "wouter";

export default function AdminDashboard() {
  const { user } = useAuth();

  // Fetch students
  const { data: students, isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
    enabled: !!user,
  });

  // Fetch teachers
  const { data: teachers, isLoading: teachersLoading } = useQuery<Teacher[]>({
    queryKey: ["/api/teachers"],
    enabled: !!user,
  });

  // Fetch classes
  const { data: classes, isLoading: classesLoading } = useQuery<Class[]>({
    queryKey: ["/api/classes"],
    enabled: !!user,
  });

  // Distribution of students by class
  const studentsByClass = students?.reduce<Record<string, number>>((acc, student) => {
    const classId = student.classId ? student.classId.toString() : "Unassigned";
    acc[classId] = (acc[classId] || 0) + 1;
    return acc;
  }, {}) || {};

  return (
    <DashboardLayout pageTitle="Admin Dashboard">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">
          Admin Dashboard
        </h2>
        <p className="text-slate-500">Manage students, teachers and system settings</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Total Students</p>
                {studentsLoading ? (
                  <Skeleton className="h-10 w-16 mt-1" />
                ) : (
                  <h3 className="text-3xl font-bold text-slate-700">{students?.length || 0}</h3>
                )}
              </div>
              <div className="rounded-full p-3 bg-indigo-100">
                <UserSquare className="h-5 w-5 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Total Teachers</p>
                {teachersLoading ? (
                  <Skeleton className="h-10 w-16 mt-1" />
                ) : (
                  <h3 className="text-3xl font-bold text-slate-700">{teachers?.length || 0}</h3>
                )}
              </div>
              <div className="rounded-full p-3 bg-blue-100">
                <Presentation className="h-5 w-5 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-slate-500 text-sm">Classes</p>
                {classesLoading ? (
                  <Skeleton className="h-10 w-16 mt-1" />
                ) : (
                  <h3 className="text-3xl font-bold text-slate-700">{classes?.length || 0}</h3>
                )}
              </div>
              <div className="rounded-full p-3 bg-green-100">
                <School className="h-5 w-5 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold text-slate-800">Student Distribution</h3>
            </div>
            
            {studentsLoading || classesLoading ? (
              <Skeleton className="h-60 w-full" />
            ) : students && students.length > 0 ? (
              <Chart className="w-full aspect-[4/3]">
                <ChartContainer>
                  <ChartContent>
                    {Object.entries(studentsByClass).map(([classId, count], i) => (
                      <ChartBar 
                        key={classId}
                        value={count} 
                        name={classId === "Unassigned" ? "Unassigned" : `Class ${classes?.find(c => c.id.toString() === classId)?.name || classId}`}
                        color={`var(--chart-${(i % 5) + 1})`}
                      />
                    ))}
                  </ChartContent>
                  <ChartAxisX />
                  <ChartAxisY />
                </ChartContainer>
                <ChartLegend />
              </Chart>
            ) : (
              <div className="flex items-center justify-center h-60 text-slate-500">
                No student data available
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold text-slate-800">Quick Actions</h3>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <Link href="/admin/students">
                <Button className="w-full justify-start">
                  <UserSquare className="mr-2 h-5 w-5" />
                  Manage Students
                  <ArrowRight className="ml-auto h-5 w-5" />
                </Button>
              </Link>
              
              <Link href="/admin/teachers">
                <Button className="w-full justify-start">
                  <Presentation className="mr-2 h-5 w-5" />
                  Manage Teachers
                  <ArrowRight className="ml-auto h-5 w-5" />
                </Button>
              </Link>
              
              <Link href="/admin/settings">
                <Button className="w-full justify-start">
                  <School className="mr-2 h-5 w-5" />
                  System Settings
                  <ArrowRight className="ml-auto h-5 w-5" />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold text-slate-800">Recent Students</h3>
              <Link href="/admin/students">
                <Button variant="ghost" size="sm" className="text-primary">
                  View All <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </Link>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ID</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Name</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Class</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {studentsLoading ? (
                    Array(5).fill(0).map((_, index) => (
                      <tr key={index}>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Skeleton className="h-4 w-16" />
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Skeleton className="h-4 w-24" />
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Skeleton className="h-4 w-12" />
                        </td>
                      </tr>
                    ))
                  ) : students && students.length > 0 ? (
                    students.slice(0, 5).map((student) => (
                      <tr key={student.id}>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">{student.studentId}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                          {student.user?.name || "Unknown"}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                          {student.classId ? `Class ${student.classId}` : "Unassigned"}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="px-4 py-3 whitespace-nowrap text-sm text-center text-slate-500">
                        No students available
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold text-slate-800">Recent Teachers</h3>
              <Link href="/admin/teachers">
                <Button variant="ghost" size="sm" className="text-primary">
                  View All <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </Link>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200">
                <thead className="bg-slate-50">
                  <tr>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ID</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Name</th>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Subject</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {teachersLoading ? (
                    Array(5).fill(0).map((_, index) => (
                      <tr key={index}>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Skeleton className="h-4 w-16" />
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Skeleton className="h-4 w-24" />
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Skeleton className="h-4 w-12" />
                        </td>
                      </tr>
                    ))
                  ) : teachers && teachers.length > 0 ? (
                    teachers.slice(0, 5).map((teacher) => (
                      <tr key={teacher.id}>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">{teacher.teacherId}</td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                          {teacher.user?.name || "Unknown"}
                        </td>
                        <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                          {teacher.subject || "N/A"}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="px-4 py-3 whitespace-nowrap text-sm text-center text-slate-500">
                        No teachers available
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
