import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Student, StudentWithMarks, InsertStudent, InsertUser, User } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Edit, Loader2, Plus, Search, Trash2 } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

// Combined form schema for creating/editing students
const studentFormSchema = z.object({
  name: z.string().min(1, "Name is required"),
  username: z.string().min(1, "Username is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  email: z.string().email("Invalid email address"),
  classId: z.string().optional(),
  studentId: z.string().min(1, "Student ID is required"),
});

type StudentFormValues = z.infer<typeof studentFormSchema>;

export default function AdminStudents() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [currentStudent, setCurrentStudent] = useState<StudentWithMarks | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [studentToDelete, setStudentToDelete] = useState<StudentWithMarks | null>(null);
  const itemsPerPage = 10;

  // Fetch students
  const { data: students, isLoading } = useQuery<StudentWithMarks[]>({
    queryKey: ["/api/students"],
    enabled: !!user,
  });

  // Fetch classes
  const { data: classes } = useQuery<{ id: number; name: string }[]>({
    queryKey: ["/api/classes"],
    enabled: !!user,
  });

  // Student form
  const form = useForm<StudentFormValues>({
    resolver: zodResolver(studentFormSchema),
    defaultValues: {
      name: "",
      username: "",
      password: "stud123",
      email: "",
      classId: "",
      studentId: "",
    },
  });

  // Create/update student mutation
  const studentMutation = useMutation({
    mutationFn: async (values: StudentFormValues) => {
      // Prepare user data
      const userData: InsertUser = {
        username: values.username,
        password: values.password,
        name: values.name,
        role: "student",
        email: values.email,
        classId: values.classId ? parseInt(values.classId) : undefined,
      };

      // Prepare student data
      const studentData = {
        studentId: values.studentId,
        classId: values.classId ? parseInt(values.classId) : undefined,
      };

      if (currentStudent) {
        // Update user
        await apiRequest("PUT", `/api/users/${currentStudent.userId}`, userData);
        // Update student
        await apiRequest("PUT", `/api/students/${currentStudent.id}`, studentData);
      } else {
        // Register new user with student role and get user ID
        const userResponse = await apiRequest("POST", "/api/register", {
          ...userData,
          studentId: values.studentId,
        });
        const newUser: User = await userResponse.json();

        // No need to create student record separately as it's handled in the registration
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      setDialogOpen(false);
      toast({
        title: currentStudent ? "Student Updated" : "Student Created",
        description: currentStudent 
          ? "The student has been updated successfully." 
          : "A new student has been created successfully.",
      });
      setCurrentStudent(null);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${currentStudent ? "update" : "create"} student: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete student mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/students/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      setDeleteDialogOpen(false);
      toast({
        title: "Student Deleted",
        description: "The student has been deleted successfully.",
      });
      setStudentToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete student: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: StudentFormValues) => {
    // Process classId - convert 'none' to null, empty string to null
    const processedValues = {
      ...values,
      classId: values.classId === 'none' || values.classId === '' 
        ? null 
        : values.classId
    };
    
    console.log("Submitting student form with values:", processedValues);
    studentMutation.mutate(processedValues as StudentFormValues);
  };

  // Open dialog for creating new student
  const openCreateDialog = () => {
    setCurrentStudent(null);
    form.reset({
      name: "",
      username: "",
      password: "stud123",
      email: "",
      classId: "none", // Use 'none' instead of empty string
      studentId: "",
    });
    setDialogOpen(true);
  };

  // Open dialog for editing student
  const openEditDialog = (student: StudentWithMarks) => {
    setCurrentStudent(student);
    form.reset({
      name: student.user?.name || "",
      username: student.user?.username || "",
      password: "", // Don't set password for edit
      email: student.user?.email || "",
      classId: student.classId ? student.classId.toString() : "none",
      studentId: student.studentId,
    });
    setDialogOpen(true);
  };

  // Open delete confirmation dialog
  const openDeleteDialog = (student: StudentWithMarks) => {
    setStudentToDelete(student);
    setDeleteDialogOpen(true);
  };

  // Delete the student
  const confirmDelete = () => {
    if (studentToDelete) {
      deleteMutation.mutate(studentToDelete.id);
    }
  };

  // Filter students by search query
  const filteredStudents = students?.filter(student => 
    student.user?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    student.studentId.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  // Paginate students
  const totalPages = Math.ceil(filteredStudents.length / itemsPerPage);
  const paginatedStudents = filteredStudents.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <DashboardLayout pageTitle="Manage Students">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Manage Students</h2>
          <p className="text-slate-500">Add, edit, or delete student records</p>
        </div>
        <Button onClick={openCreateDialog}>
          <Plus className="mr-2 h-4 w-4" />
          Add Student
        </Button>
      </div>

      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="mb-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-slate-400" />
              </div>
              <Input
                placeholder="Search students..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1); // Reset to first page on search
                }}
              />
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ID</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Name</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Class</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Email</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-slate-200">
                {isLoading ? (
                  Array(5).fill(0).map((_, index) => (
                    <tr key={index}>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-16" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-24" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-12" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <Skeleton className="h-4 w-32" />
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex space-x-2">
                          <Skeleton className="h-8 w-8 rounded-full" />
                          <Skeleton className="h-8 w-8 rounded-full" />
                        </div>
                      </td>
                    </tr>
                  ))
                ) : paginatedStudents.length > 0 ? (
                  paginatedStudents.map((student) => (
                    <tr key={student.id}>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">{student.studentId}</td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                        {student.user?.name || "Unknown"}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                        {student.classId 
                          ? classes?.find(c => c.id === student.classId)?.name || `Class ${student.classId}` 
                          : "Not Assigned"}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-slate-900">
                        {student.user?.email || "N/A"}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm">
                        <div className="flex space-x-2">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-blue-500 hover:text-blue-700"
                            onClick={() => openEditDialog(student)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-red-500 hover:text-red-700"
                            onClick={() => openDeleteDialog(student)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-4 py-3 whitespace-nowrap text-sm text-center text-slate-500">
                      {searchQuery ? "No students found matching your search" : "No students available"}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          {/* Pagination */}
          {filteredStudents.length > 0 && (
            <div className="mt-4 flex justify-between items-center">
              <p className="text-sm text-slate-500">
                Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, filteredStudents.length)} of {filteredStudents.length} students
              </p>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                >
                  Previous
                </Button>
                <Button 
                  variant={currentPage === totalPages ? "outline" : "default"}
                  size="sm"
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create/Edit Student Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>{currentStudent ? "Edit Student" : "Add New Student"}</DialogTitle>
            <DialogDescription>
              {currentStudent 
                ? "Update student information in the system." 
                : "Add a new student to the academic system."}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter student's full name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex space-x-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Username for login" 
                          {...field} 
                          disabled={!!currentStudent}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="studentId"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel>Student ID</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g. ST001" 
                          {...field} 
                          disabled={!!currentStudent}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="flex space-x-4">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input 
                          type="email" 
                          placeholder="student@example.com" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="classId"
                  render={({ field }) => (
                    <FormItem className="flex-1">
                      <FormLabel>Class</FormLabel>
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a class" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">Not Assigned</SelectItem>
                          {classes?.map((cls) => (
                            <SelectItem key={cls.id} value={cls.id.toString() || "none"}>
                              {cls.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              {!currentStudent && (
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input 
                          type="password" 
                          placeholder="Enter password" 
                          {...field} 
                        />
                      </FormControl>
                      <p className="text-xs text-slate-500">Default password: stud123</p>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={studentMutation.isPending}
                >
                  {studentMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  {currentStudent ? "Update" : "Add"} Student
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the student record for {studentToDelete?.user?.name || studentToDelete?.studentId}. 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-red-500 hover:bg-red-600"
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </DashboardLayout>
  );
}
