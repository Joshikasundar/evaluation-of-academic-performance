import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Label } from "@/components/ui/label";
import { AlertCircle, Check, Loader2, Save } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function AdminSettings() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Academic settings state
  const [academicYear, setAcademicYear] = useState("2023-2024");
  const [gradingSystem, setGradingSystem] = useState("Percentage");
  const [minAttendance, setMinAttendance] = useState(75);

  // System preferences state
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [parentAccess, setParentAccess] = useState(true);
  const [studentFeedback, setStudentFeedback] = useState(true);
  const [dataBackupFrequency, setDataBackupFrequency] = useState("Daily");

  // Handle save settings
  const handleSaveSettings = () => {
    setIsSaving(true);
    
    // Mock save operation with timeout
    setTimeout(() => {
      setIsSaving(false);
      setIsEditing(false);
      
      toast({
        title: "Settings Saved",
        description: "Your system settings have been updated successfully.",
      });
    }, 1000);
  };

  return (
    <DashboardLayout pageTitle="System Settings">
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">System Settings</h2>
          <p className="text-slate-500">Configure academic and system preferences</p>
        </div>
        <div className="flex space-x-2">
          {isEditing ? (
            <>
              <Button 
                variant="outline" 
                onClick={() => setIsEditing(false)}
                disabled={isSaving}
              >
                Cancel
              </Button>
              <Button 
                onClick={handleSaveSettings}
                disabled={isSaving}
              >
                {isSaving ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Save className="mr-2 h-4 w-4" />
                )}
                Save Changes
              </Button>
            </>
          ) : (
            <Button onClick={() => setIsEditing(true)}>
              Edit Settings
            </Button>
          )}
        </div>
      </div>

      <Tabs defaultValue="academic">
        <TabsList className="mb-6">
          <TabsTrigger value="academic">Academic Settings</TabsTrigger>
          <TabsTrigger value="system">System Preferences</TabsTrigger>
          <TabsTrigger value="backup">Backup & Recovery</TabsTrigger>
        </TabsList>
        
        <TabsContent value="academic">
          <Card>
            <CardHeader>
              <CardTitle>Academic Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="academicYear">Current Academic Year</Label>
                  <Select
                    value={academicYear}
                    onValueChange={setAcademicYear}
                    disabled={!isEditing}
                  >
                    <SelectTrigger id="academicYear" className="mt-1">
                      <SelectValue placeholder="Select academic year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2023-2024">2023-2024</SelectItem>
                      <SelectItem value="2022-2023">2022-2023</SelectItem>
                      <SelectItem value="2021-2022">2021-2022</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="gradingSystem">Grading System</Label>
                  <Select
                    value={gradingSystem}
                    onValueChange={setGradingSystem}
                    disabled={!isEditing}
                  >
                    <SelectTrigger id="gradingSystem" className="mt-1">
                      <SelectValue placeholder="Select grading system" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Percentage">Percentage Based</SelectItem>
                      <SelectItem value="GPA">GPA Based</SelectItem>
                      <SelectItem value="Letter">Letter Grade</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="minAttendance">Minimum Attendance Required (%)</Label>
                  <Input 
                    id="minAttendance"
                    type="number"
                    min={0}
                    max={100}
                    value={minAttendance}
                    onChange={(e) => setMinAttendance(parseInt(e.target.value))}
                    disabled={!isEditing}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="examWeightage">Exam Weightage (%)</Label>
                  <Input 
                    id="examWeightage"
                    type="number"
                    min={0}
                    max={100}
                    defaultValue={70}
                    disabled={!isEditing}
                    className="mt-1"
                  />
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h4 className="text-sm font-medium mb-2">Grade Distribution</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">O Grade (Excellent)</span>
                    <div className="flex items-center space-x-2">
                      <Input 
                        type="number" 
                        defaultValue={90}
                        min={0}
                        max={100}
                        disabled={!isEditing}
                        className="w-20"
                      />
                      <span className="text-sm">to</span>
                      <Input 
                        type="number" 
                        defaultValue={100}
                        min={0}
                        max={100}
                        disabled={!isEditing}
                        className="w-20"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">A Grade (Super)</span>
                    <div className="flex items-center space-x-2">
                      <Input 
                        type="number" 
                        defaultValue={80}
                        min={0}
                        max={100}
                        disabled={!isEditing}
                        className="w-20"
                      />
                      <span className="text-sm">to</span>
                      <Input 
                        type="number" 
                        defaultValue={89}
                        min={0}
                        max={100}
                        disabled={!isEditing}
                        className="w-20"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">B Grade (Good)</span>
                    <div className="flex items-center space-x-2">
                      <Input 
                        type="number" 
                        defaultValue={70}
                        min={0}
                        max={100}
                        disabled={!isEditing}
                        className="w-20"
                      />
                      <span className="text-sm">to</span>
                      <Input 
                        type="number" 
                        defaultValue={79}
                        min={0}
                        max={100}
                        disabled={!isEditing}
                        className="w-20"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">C Grade (Not Bad)</span>
                    <div className="flex items-center space-x-2">
                      <Input 
                        type="number" 
                        defaultValue={40}
                        min={0}
                        max={100}
                        disabled={!isEditing}
                        className="w-20"
                      />
                      <span className="text-sm">to</span>
                      <Input 
                        type="number" 
                        defaultValue={69}
                        min={0}
                        max={100}
                        disabled={!isEditing}
                        className="w-20"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <span className="text-sm">F Grade (Needs Practice)</span>
                    <div className="flex items-center space-x-2">
                      <Input 
                        type="number" 
                        defaultValue={0}
                        min={0}
                        max={100}
                        disabled={!isEditing}
                        className="w-20"
                      />
                      <span className="text-sm">to</span>
                      <Input 
                        type="number" 
                        defaultValue={39}
                        min={0}
                        max={100}
                        disabled={!isEditing}
                        className="w-20"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="system">
          <Card>
            <CardHeader>
              <CardTitle>System Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="emailNotifications">Email Notifications</Label>
                    <p className="text-sm text-slate-500">Receive email notifications for important events</p>
                  </div>
                  <Switch 
                    id="emailNotifications" 
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                    disabled={!isEditing}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="parentAccess">Parent Portal Access</Label>
                    <p className="text-sm text-slate-500">Allow parents to access the student portal</p>
                  </div>
                  <Switch 
                    id="parentAccess" 
                    checked={parentAccess}
                    onCheckedChange={setParentAccess}
                    disabled={!isEditing}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="studentFeedback">Student Feedback</Label>
                    <p className="text-sm text-slate-500">Allow students to provide feedback on teaching</p>
                  </div>
                  <Switch 
                    id="studentFeedback" 
                    checked={studentFeedback}
                    onCheckedChange={setStudentFeedback}
                    disabled={!isEditing}
                  />
                </div>
                
                <Separator />
                
                <div className="space-y-1.5">
                  <Label htmlFor="dataBackupFrequency">Data Backup Frequency</Label>
                  <Select
                    value={dataBackupFrequency}
                    onValueChange={setDataBackupFrequency}
                    disabled={!isEditing}
                  >
                    <SelectTrigger id="dataBackupFrequency">
                      <SelectValue placeholder="Select backup frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Daily">Daily</SelectItem>
                      <SelectItem value="Weekly">Weekly</SelectItem>
                      <SelectItem value="Monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h4 className="text-sm font-medium mb-3">User Permissions</h4>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="teacherEditMarks" 
                      defaultChecked 
                      disabled={!isEditing}
                    />
                    <Label htmlFor="teacherEditMarks">Teachers can edit student marks</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="teacherScheduleMeetings" 
                      defaultChecked 
                      disabled={!isEditing}
                    />
                    <Label htmlFor="teacherScheduleMeetings">Teachers can schedule parent meetings</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="parentViewMarks" 
                      defaultChecked 
                      disabled={!isEditing}
                    />
                    <Label htmlFor="parentViewMarks">Parents can view student marks</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="studentViewAllMarks" 
                      defaultChecked 
                      disabled={!isEditing}
                    />
                    <Label htmlFor="studentViewAllMarks">Students can view all subject marks</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="backup">
          <Card>
            <CardHeader>
              <CardTitle>Backup & Data Management</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Important information</AlertTitle>
                <AlertDescription>
                  Regular backups are essential to prevent data loss. Configure your backup settings below.
                </AlertDescription>
              </Alert>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label>Last Backup</Label>
                  <p className="text-sm text-slate-600 mt-1">September 21, 2023 at 3:45 PM</p>
                </div>
                
                <div>
                  <Label>Next Scheduled Backup</Label>
                  <p className="text-sm text-slate-600 mt-1">September 22, 2023 at 3:45 PM</p>
                </div>
                
                <div>
                  <Label>Backup Location</Label>
                  <div className="flex mt-1">
                    <Input 
                      defaultValue="/backups/academic_system"
                      disabled={!isEditing}
                      className="rounded-r-none"
                    />
                    <Button 
                      variant="outline" 
                      className="rounded-l-none"
                      disabled={!isEditing}
                    >
                      Browse
                    </Button>
                  </div>
                </div>
                
                <div>
                  <Label>Retention Period</Label>
                  <Select disabled={!isEditing} defaultValue="30">
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select retention period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 days</SelectItem>
                      <SelectItem value="14">14 days</SelectItem>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="365">1 year</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="compressBackups" 
                    defaultChecked 
                    disabled={!isEditing}
                  />
                  <Label htmlFor="compressBackups">Compress backups</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="encryptBackups" 
                    defaultChecked 
                    disabled={!isEditing}
                  />
                  <Label htmlFor="encryptBackups">Encrypt backups</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="notifyOnFailure" 
                    defaultChecked 
                    disabled={!isEditing}
                  />
                  <Label htmlFor="notifyOnFailure">Notify admin on backup failure</Label>
                </div>
              </div>
              
              <div className="flex flex-col gap-2 sm:flex-row sm:gap-4">
                <Button 
                  className="flex items-center" 
                  disabled={!isEditing}
                >
                  <Check className="mr-2 h-4 w-4" />
                  Run Backup Now
                </Button>
                
                <Button 
                  variant="outline" 
                  className="flex items-center"
                  disabled={!isEditing}
                >
                  Restore from Backup
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
}
