import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Student, StudentWithMarks, MeetingWithDetails } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { calculateOverallGrade, formatDate, calculateGrade } from "@/lib/utils";
import { GRADE_COLORS } from "@/lib/constants";
import { UserSquare, Search, CalendarDays, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function ParentDashboard() {
  const { user } = useAuth();
  const [studentName, setStudentName] = useState("");
  const [searchClicked, setSearchClicked] = useState(false);

  // Fetch all students to find by name
  const { data: allStudents } = useQuery<StudentWithMarks[]>({
    queryKey: ["/api/students"],
    enabled: !!user
  });
  
  // Find student by name
  const student = searchClicked && studentName ? 
    allStudents?.find(s => s.user?.name?.toLowerCase().includes(studentName.toLowerCase())) : 
    undefined;

  // Fetch meetings
  const { data: meetings, isLoading: meetingsLoading } = useQuery<MeetingWithDetails[]>({
    queryKey: [`/api/students/${student?.id}/meetings`],
    enabled: !!student?.id,
  });

  // Loading state
  const isLoading = !student && searchClicked;

  // Calculate overall grade
  const overallGrade = student && student.marks?.length
    ? calculateOverallGrade(student.marks)
    : { percentage: 0, grade: "N/A", message: "No data available" };

  // Calculate attendance percentage
  const attendanceCount = student?.attendance?.length ?? 0;
  const presentCount = student?.attendance?.filter(a => a.status === "present").length ?? 0;
  const attendancePercentage = attendanceCount > 0 
    ? Math.round((presentCount / attendanceCount) * 100) 
    : 0;

  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchClicked(true);
  };

  // Get grade colors
  const gradeColor = overallGrade.grade !== "N/A" 
    ? GRADE_COLORS[overallGrade.grade as keyof typeof GRADE_COLORS] 
    : GRADE_COLORS.C;

  // Get upcoming meetings
  const upcomingMeetings = meetings
    ?.filter(meeting => new Date(meeting.meetingDate) > new Date())
    .sort((a, b) => new Date(a.meetingDate).getTime() - new Date(b.meetingDate).getTime())
    .slice(0, 1) || [];

  return (
    <DashboardLayout pageTitle="Parent Dashboard">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">
          Welcome, {user?.name}
        </h2>
        <p className="text-slate-500">View your child's academic performance</p>
      </div>

      <Card className="mb-8">
        <CardContent className="p-6">
          <h3 className="text-xl font-semibold text-slate-800 mb-4">Student Lookup</h3>
          <form className="flex flex-col md:flex-row md:items-end gap-4" onSubmit={handleSearch}>
            <div className="flex-grow">
              <label className="block text-sm font-medium text-slate-700 mb-1">Enter Student Name</label>
              <Input 
                type="text" 
                placeholder="e.g. John Smith" 
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
              />
            </div>
            <Button type="submit" disabled={!studentName}>View Performance</Button>
          </form>
        </CardContent>
      </Card>

      {searchClicked && (
        isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
            {Array(4).fill(0).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-8 w-32 mb-2" />
                  <Skeleton className="h-4 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : student ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-slate-500 text-sm">Student Name</p>
                      <h3 className="text-xl font-bold text-slate-700">{student.user?.name}</h3>
                    </div>
                    <div className="rounded-full p-2 bg-indigo-100">
                      <UserSquare className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                  <p className="mt-2 text-sm text-slate-600">Class: {student.classId ? `Class ${student.classId}` : "N/A"}</p>
                  <p className="text-sm text-slate-600">ID: {student.studentId}</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-slate-500 text-sm">Overall Grade</p>
                      <h3 className="text-3xl font-bold text-emerald-500">{overallGrade.grade}</h3>
                    </div>
                    <span className={`${gradeColor.bg} ${gradeColor.text} text-xs px-3 py-1 rounded-full`}>
                      {overallGrade.grade === "N/A" ? "Not Available" : "Excellent"}
                    </span>
                  </div>
                  <p className="mt-4 text-sm text-slate-600">"{overallGrade.message}"</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-slate-500 text-sm">Attendance</p>
                      <h3 className="text-3xl font-bold text-slate-700">{attendancePercentage}%</h3>
                    </div>
                    <span className={`bg-${attendancePercentage >= 75 ? 'green' : 'amber'}-100 text-${attendancePercentage >= 75 ? 'green' : 'amber'}-600 text-xs px-3 py-1 rounded-full`}>
                      {attendancePercentage >= 75 ? 'Good' : 'Warning'}
                    </span>
                  </div>
                  <div className="mt-4">
                    <div className="w-full bg-slate-200 rounded-full h-2">
                      <div 
                        className={`bg-${attendancePercentage >= 75 ? 'green' : 'amber'}-500 h-2 rounded-full`}
                        style={{ width: `${attendancePercentage}%` }}
                      ></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-slate-500 text-sm">Next Parent Meeting</p>
                      {meetingsLoading ? (
                        <Skeleton className="h-6 w-32 mt-1" />
                      ) : upcomingMeetings.length > 0 ? (
                        <h3 className="text-xl font-bold text-slate-700">{formatDate(upcomingMeetings[0].meetingDate)}</h3>
                      ) : (
                        <h3 className="text-xl font-bold text-slate-700">Not Scheduled</h3>
                      )}
                    </div>
                    <div className="rounded-full p-2 bg-amber-100">
                      <CalendarDays className="h-5 w-5 text-amber-500" />
                    </div>
                  </div>
                  {!meetingsLoading && upcomingMeetings.length > 0 && (
                    <>
                      <p className="mt-2 text-sm text-slate-600">Time: {upcomingMeetings[0].startTime} - {upcomingMeetings[0].endTime}</p>
                      <p className="text-sm text-slate-600">With: {upcomingMeetings[0].teacher?.user?.name || 'Teacher'}</p>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>

            <Card className="mb-8">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-slate-800 mb-4">Academic Performance</h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-slate-200">
                    <thead className="bg-slate-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Subject</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Marks</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Grade</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Performance</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-slate-200">
                      {student.marks && student.marks.length > 0 ? (
                        student.marks.map((mark) => {
                          const percentage = (mark.marks / mark.maxMarks) * 100;
                          const gradeObj = calculateGrade(percentage);
                          const color = GRADE_COLORS[gradeObj.grade as keyof typeof GRADE_COLORS];
                          
                          return (
                            <tr key={mark.id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-medium text-slate-900">{mark.subject.name}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-slate-900">{mark.marks}/{mark.maxMarks}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${color.bg} ${color.text}`}>
                                  {gradeObj.grade}
                                </span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                                <div className="w-full bg-slate-200 rounded-full h-2">
                                  <div 
                                    className={`${color.progress} h-2 rounded-full`} 
                                    style={{ width: `${percentage}%` }}
                                  ></div>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={4} className="px-6 py-4 text-center text-slate-500">
                            No marks data available
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-slate-800">Attendance Report</h3>
                  </div>
                  <div className="grid grid-cols-7 gap-2 mb-4">
                    {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
                      <div key={i} className="h-8 flex items-center justify-center text-xs font-medium text-slate-500">{day}</div>
                    ))}
                    
                    {/* Sample calendar view */}
                    {Array(14).fill(0).map((_, i) => {
                      const day = i + 1;
                      const statuses = ['present', 'absent', 'od', 'present'];
                      const status = i < student.attendance?.length 
                        ? student.attendance[i % student.attendance.length].status 
                        : (i % 7 < 5 ? statuses[i % 4] : null);
                      
                      return (
                        <div 
                          key={i}
                          className={`h-10 flex items-center justify-center rounded border text-sm font-medium ${
                            status === 'present' 
                              ? 'bg-green-100 text-green-800 border-green-500' 
                              : status === 'absent' 
                                ? 'bg-red-100 text-red-800 border-red-500' 
                                : status === 'od' 
                                  ? 'bg-yellow-100 text-yellow-800 border-yellow-500' 
                                  : ''
                          }`}
                        >
                          {day}
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex items-center justify-center space-x-6">
                    <div className="flex items-center">
                      <div className="w-4 h-4 bg-green-500 rounded-full mr-2"></div>
                      <span className="text-sm text-slate-700">Present</span>
                    </div>
                    <div className="flex items-center">
                      <div className="w-4 h-4 bg-red-500 rounded-full mr-2"></div>
                      <span className="text-sm text-slate-700">Absent</span>
                    </div>
                    <div className="flex items-center">
                      <div className="w-4 h-4 bg-yellow-500 rounded-full mr-2"></div>
                      <span className="text-sm text-slate-700">OD</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-semibold text-slate-800">Upcoming Parent Meetings</h3>
                    <Link href="/parent/meetings">
                      <Button variant="ghost" size="sm" className="text-primary">
                        View All <ArrowRight className="ml-1 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                  {meetingsLoading ? (
                    <Skeleton className="h-24 w-full" />
                  ) : upcomingMeetings.length > 0 ? (
                    <div className="p-4 border-l-4 border-primary bg-indigo-50 rounded">
                      <div className="flex">
                        <div className="flex-shrink-0">
                          <CalendarDays className="text-primary" />
                        </div>
                        <div className="ml-3">
                          <h3 className="text-sm font-medium text-indigo-800">Mid-term Performance Review</h3>
                          <div className="mt-1 text-sm text-indigo-700">
                            <p className="font-medium">Date: {formatDate(upcomingMeetings[0].meetingDate)}</p>
                            <p>Time: {upcomingMeetings[0].startTime} - {upcomingMeetings[0].endTime}</p>
                            <p>Teacher: {upcomingMeetings[0].teacher?.user?.name || 'Not specified'}</p>
                          </div>
                          <p className="text-xs text-indigo-500 mt-2">Room: 105, Main Building</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-6 text-slate-500">
                      No upcoming meetings scheduled
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <h3 className="text-lg font-medium text-slate-800 mb-2">Student Not Found</h3>
              <p className="text-slate-500 mb-4">Please check the student name and try again.</p>
              <Button 
                variant="outline" 
                onClick={() => setSearchClicked(false)}
              >
                Try Again
              </Button>
            </CardContent>
          </Card>
        )
      )}
    </DashboardLayout>
  );
}
