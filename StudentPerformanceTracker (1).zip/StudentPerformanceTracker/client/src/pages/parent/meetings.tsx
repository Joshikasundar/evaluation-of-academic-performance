import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Student, StudentWithMarks, Meeting } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatDate } from "@/lib/utils";
import { Calendar, CalendarDays, Clock, MapPin, User } from "lucide-react";
import { format } from "date-fns";

export default function ParentMeetings() {
  const { user } = useAuth();
  const [studentId, setStudentId] = useState("");
  const [searchClicked, setSearchClicked] = useState(false);

  // Fetch student information if search is clicked
  const { data: student, isLoading: studentLoading } = useQuery<StudentWithMarks>({
    queryKey: [`/api/students/${studentId}`],
    enabled: !!studentId && searchClicked,
    onError: () => setSearchClicked(false)
  });

  // Fetch meetings
  const { data: meetings, isLoading: meetingsLoading } = useQuery<Meeting[]>({
    queryKey: [`/api/students/${student?.id}/meetings`],
    enabled: !!student?.id,
  });

  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchClicked(true);
  };

  // Group meetings by month
  const meetingsByMonth = meetings?.reduce<Record<string, Meeting[]>>((acc, meeting) => {
    const month = format(new Date(meeting.meetingDate), "MMMM yyyy");
    if (!acc[month]) {
      acc[month] = [];
    }
    acc[month].push(meeting);
    return acc;
  }, {}) || {};

  // Sort and get upcoming and past meetings
  const upcomingMeetings = meetings
    ?.filter(meeting => new Date(meeting.meetingDate) >= new Date())
    .sort((a, b) => new Date(a.meetingDate).getTime() - new Date(b.meetingDate).getTime()) || [];
  
  const pastMeetings = meetings
    ?.filter(meeting => new Date(meeting.meetingDate) < new Date())
    .sort((a, b) => new Date(b.meetingDate).getTime() - new Date(a.meetingDate).getTime()) || [];

  return (
    <DashboardLayout pageTitle="Parent-Teacher Meetings">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Parent-Teacher Meetings</h2>
        <p className="text-slate-500">View scheduled meetings with teachers</p>
      </div>

      <Card className="mb-8">
        <CardContent className="p-6">
          <form className="flex flex-col md:flex-row md:items-end gap-4" onSubmit={handleSearch}>
            <div className="flex-grow">
              <label className="block text-sm font-medium text-slate-700 mb-1">Enter Student ID</label>
              <Input 
                type="text" 
                placeholder="e.g. ST001" 
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
              />
            </div>
            <Button type="submit" disabled={!studentId}>View Meetings</Button>
          </form>
        </CardContent>
      </Card>

      {searchClicked && (
        studentLoading ? (
          <Skeleton className="h-60 w-full rounded-lg" />
        ) : student ? (
          <>
            <Card className="mb-6">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-slate-800">Student Details</h3>
                    <p className="text-slate-500">ID: {student.studentId}</p>
                  </div>
                  <div className="mt-4 md:mt-0">
                    <h4 className="text-lg font-semibold text-slate-800">{student.user?.name}</h4>
                    <p className="text-slate-500">Class: {student.classId || "N/A"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {meetingsLoading ? (
              <div className="space-y-6">
                <Skeleton className="h-40 w-full rounded-lg" />
                <Skeleton className="h-40 w-full rounded-lg" />
              </div>
            ) : (
              <>
                <div className="mb-8">
                  <h3 className="text-xl font-semibold text-slate-800 mb-4">Upcoming Meetings</h3>
                  {upcomingMeetings.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {upcomingMeetings.map((meeting) => (
                        <Card key={meeting.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-6">
                            <div className="flex items-center justify-between mb-4">
                              <div className="bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full">
                                Upcoming
                              </div>
                              <p className="text-sm text-slate-500">
                                {new Date(meeting.meetingDate) > new Date() ? "In " + Math.ceil((new Date(meeting.meetingDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) + " days" : "Today"}
                              </p>
                            </div>
                            <h4 className="text-lg font-medium mb-3">Performance Review</h4>
                            <div className="space-y-2">
                              <div className="flex items-center text-sm">
                                <Calendar className="mr-2 h-4 w-4 text-primary" />
                                <span>{formatDate(meeting.meetingDate)}</span>
                              </div>
                              <div className="flex items-center text-sm">
                                <Clock className="mr-2 h-4 w-4 text-primary" />
                                <span>{meeting.startTime} - {meeting.endTime}</span>
                              </div>
                              <div className="flex items-center text-sm">
                                <User className="mr-2 h-4 w-4 text-primary" />
                                <span>Teacher: {meeting.teacher?.user?.name || "Teacher"}</span>
                              </div>
                              <div className="flex items-center text-sm">
                                <MapPin className="mr-2 h-4 w-4 text-primary" />
                                <span>Room 105, Main Building</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <Card>
                      <CardContent className="p-6 text-center py-12">
                        <CalendarDays className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                        <h4 className="text-lg font-medium text-slate-700 mb-2">No Upcoming Meetings</h4>
                        <p className="text-slate-500">
                          There are no upcoming meetings scheduled for this student.
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </div>

                {pastMeetings.length > 0 && (
                  <div>
                    <h3 className="text-xl font-semibold text-slate-800 mb-4">Past Meetings</h3>
                    <Card>
                      <CardContent className="p-6">
                        <div className="space-y-6">
                          {Object.entries(meetingsByMonth)
                            .filter(([month, meetings]) => meetings.some(m => new Date(m.meetingDate) < new Date()))
                            .map(([month, monthMeetings]) => {
                              const filteredMeetings = monthMeetings.filter(m => new Date(m.meetingDate) < new Date());
                              if (filteredMeetings.length === 0) return null;
                              
                              return (
                                <div key={month}>
                                  <h4 className="text-md font-medium text-slate-700 mb-3">{month}</h4>
                                  <div className="space-y-3">
                                    {filteredMeetings.map((meeting) => (
                                      <div key={meeting.id} className="p-4 border rounded-lg bg-slate-50">
                                        <div className="flex justify-between">
                                          <h5 className="font-medium">Performance Review</h5>
                                          <span className="text-sm text-slate-500">{formatDate(meeting.meetingDate)}</span>
                                        </div>
                                        <div className="mt-2 flex items-center text-sm text-slate-600">
                                          <Clock className="mr-2 h-4 w-4 text-slate-400" />
                                          <span>{meeting.startTime} - {meeting.endTime}</span>
                                        </div>
                                        <div className="mt-1 flex items-center text-sm text-slate-600">
                                          <User className="mr-2 h-4 w-4 text-slate-400" />
                                          <span>Teacher: {meeting.teacher?.user?.name || "Teacher"}</span>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              );
                            })}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                )}
              </>
            )}
          </>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <h3 className="text-lg font-medium text-slate-800 mb-2">Student Not Found</h3>
              <p className="text-slate-500 mb-4">Please check the student ID and try again.</p>
              <Button 
                variant="outline" 
                onClick={() => setSearchClicked(false)}
              >
                Try Again
              </Button>
            </CardContent>
          </Card>
        )
      )}
    </DashboardLayout>
  );
}
