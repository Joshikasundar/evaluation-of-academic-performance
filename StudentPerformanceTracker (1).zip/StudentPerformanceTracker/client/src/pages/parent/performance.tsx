import { useState } from "react";
import { DashboardLayout } from "@/components/dashboard-layout";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Student, StudentWithMarks } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { calculateGrade, calculateOverallGrade } from "@/lib/utils";
import { GRADE_COLORS } from "@/lib/constants";
import { 
  Chart,
  ChartLegend,
  ChartBar,
  ChartContainer,
  ChartAxisX,
  ChartAxisY,
  ChartContent
} from "@/components/ui/chart";

export default function ParentPerformance() {
  const { user } = useAuth();
  const [studentId, setStudentId] = useState("");
  const [searchClicked, setSearchClicked] = useState(false);

  // Fetch student information if search is clicked
  const { data: student, isLoading: studentLoading } = useQuery<StudentWithMarks>({
    queryKey: [`/api/students/${studentId}`],
    enabled: !!studentId && searchClicked,
    onError: () => setSearchClicked(false)
  });

  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchClicked(true);
  };

  // Calculate statistics for each subject
  const subjectPerformance = student?.marks?.map((mark) => {
    const percentage = (mark.marks / mark.maxMarks) * 100;
    const { grade, message } = calculateGrade(percentage);
    return {
      ...mark,
      percentage,
      grade,
      message,
      color: GRADE_COLORS[grade as keyof typeof GRADE_COLORS]
    };
  }) || [];

  // Calculate overall statistics
  const totalMarks = student?.marks?.reduce((sum, mark) => sum + mark.marks, 0) || 0;
  const totalMaxMarks = student?.marks?.reduce((sum, mark) => sum + mark.maxMarks, 0) || 0;
  const overallPercentage = totalMaxMarks > 0 ? (totalMarks / totalMaxMarks) * 100 : 0;
  const overallGradeInfo = calculateGrade(overallPercentage);

  return (
    <DashboardLayout pageTitle="View Performance">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Student Performance</h2>
        <p className="text-slate-500">View your child's academic performance details</p>
      </div>

      <Card className="mb-8">
        <CardContent className="p-6">
          <form className="flex flex-col md:flex-row md:items-end gap-4" onSubmit={handleSearch}>
            <div className="flex-grow">
              <label className="block text-sm font-medium text-slate-700 mb-1">Enter Student ID</label>
              <Input 
                type="text" 
                placeholder="e.g. ST001" 
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
              />
            </div>
            <Button type="submit" disabled={!studentId}>View Performance</Button>
          </form>
        </CardContent>
      </Card>

      {searchClicked && (
        studentLoading ? (
          <div className="space-y-6">
            <Skeleton className="h-60 w-full rounded-lg" />
            <Skeleton className="h-40 w-full rounded-lg" />
          </div>
        ) : student ? (
          <>
            <Card className="mb-6">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold text-slate-800">Student Details</h3>
                    <p className="text-slate-500">ID: {student.studentId}</p>
                  </div>
                  <div className="mt-4 md:mt-0">
                    <h4 className="text-lg font-semibold text-slate-800">{student.user?.name}</h4>
                    <p className="text-slate-500">Class: {student.classId || "N/A"}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
              <Card className="col-span-1 lg:col-span-2">
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-slate-800 mb-4">Subject Performance</h3>
                  {student.marks && student.marks.length > 0 ? (
                    <Chart className="w-full aspect-[4/3]">
                      <ChartContainer>
                        <ChartContent>
                          {subjectPerformance.map((subject, i) => (
                            <ChartBar 
                              key={subject.id}
                              value={subject.percentage} 
                              name={subject.subject.name}
                              color={`var(--chart-${(i % 5) + 1})`}
                            />
                          ))}
                        </ChartContent>
                        <ChartAxisX />
                        <ChartAxisY />
                      </ChartContainer>
                      <ChartLegend />
                    </Chart>
                  ) : (
                    <div className="flex items-center justify-center h-60 text-slate-500">
                      No performance data available
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-slate-800 mb-4">Overall Grade</h3>
                  {student.marks && student.marks.length > 0 ? (
                    <div className="flex flex-col items-center">
                      <div className="relative h-32 w-32">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <span className="text-4xl font-bold text-primary">{Math.round(overallPercentage)}%</span>
                        </div>
                        <svg className="w-full h-full" viewBox="0 0 100 100">
                          <circle
                            className="text-slate-200"
                            strokeWidth="10"
                            stroke="currentColor"
                            fill="transparent"
                            r="40"
                            cx="50"
                            cy="50"
                          />
                          <circle
                            className="text-primary"
                            strokeWidth="10"
                            strokeDasharray={`${(overallPercentage / 100) * 251.2} 251.2`}
                            strokeLinecap="round"
                            stroke="currentColor"
                            fill="transparent"
                            r="40"
                            cx="50"
                            cy="50"
                          />
                        </svg>
                      </div>
                      <h4 className="text-xl font-semibold mt-4">{overallGradeInfo.grade} Grade</h4>
                      <p className="text-slate-500 mt-2">{overallGradeInfo.message}</p>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-60 text-slate-500">
                      No score data available
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-slate-800 mb-4">Detailed Performance</h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-slate-200">
                    <thead className="bg-slate-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Subject</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Marks</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Assignment</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Total</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Grade</th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Feedback</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-slate-200">
                      {student.marks && student.marks.length > 0 ? (
                        subjectPerformance.map((subject) => {
                          const total = subject.assignmentMarks 
                            ? (subject.marks + subject.assignmentMarks) / 2 
                            : subject.marks;
                          const percentage = (total / subject.maxMarks) * 100;
                          
                          return (
                            <tr key={subject.id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-medium text-slate-900">{subject.subject.name}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-slate-900">{subject.marks}/{subject.maxMarks}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-slate-900">{subject.assignmentMarks || "N/A"}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-slate-900">{Math.round(percentage)}%</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${subject.color.bg} ${subject.color.text}`}>
                                  {subject.grade}
                                </span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                                "{subject.message}"
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={6} className="px-6 py-4 text-center text-slate-500">
                            No performance data available
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </>
        ) : (
          <Card>
            <CardContent className="p-6 text-center">
              <h3 className="text-lg font-medium text-slate-800 mb-2">Student Not Found</h3>
              <p className="text-slate-500 mb-4">Please check the student ID and try again.</p>
              <Button 
                variant="outline" 
                onClick={() => setSearchClicked(false)}
              >
                Try Again
              </Button>
            </CardContent>
          </Card>
        )
      )}
    </DashboardLayout>
  );
}
