import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/components/protected-route";

// Student Pages
import StudentDashboard from "@/pages/student/dashboard";
import StudentPerformance from "@/pages/student/performance";
import StudentAttendance from "@/pages/student/attendance";
import StudentInfo from "@/pages/student/info";

// Teacher Pages
import TeacherDashboard from "@/pages/teacher/dashboard";
import TeacherMarks from "@/pages/teacher/marks";
import TeacherAttendance from "@/pages/teacher/attendance";
import TeacherAnnouncements from "@/pages/teacher/announcements";
import TeacherMeetings from "@/pages/teacher/meetings";

// Parent Pages
import ParentDashboard from "@/pages/parent/dashboard";
import ParentPerformance from "@/pages/parent/performance";
import ParentMeetings from "@/pages/parent/meetings";

// Admin Pages
import AdminDashboard from "@/pages/admin/dashboard";
import AdminStudents from "@/pages/admin/students";
import AdminTeachers from "@/pages/admin/teachers";
import AdminSettings from "@/pages/admin/settings";

// Other Pages
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      {/* Auth Route */}
      <Route path="/auth" component={AuthPage} />

      {/* Student Routes */}
      <ProtectedRoute path="/" role="student" component={StudentDashboard} />
      <ProtectedRoute path="/student/performance" role="student" component={StudentPerformance} />
      <ProtectedRoute path="/student/attendance" role="student" component={StudentAttendance} />
      <ProtectedRoute path="/student/info" role="student" component={StudentInfo} />

      {/* Teacher Routes */}
      <ProtectedRoute path="/teacher/dashboard" role="teacher" component={TeacherDashboard} />
      <ProtectedRoute path="/teacher/marks" role="teacher" component={TeacherMarks} />
      <ProtectedRoute path="/teacher/attendance" role="teacher" component={TeacherAttendance} />
      <ProtectedRoute path="/teacher/announcements" role="teacher" component={TeacherAnnouncements} />
      <ProtectedRoute path="/teacher/meetings" role="teacher" component={TeacherMeetings} />

      {/* Parent Routes */}
      <ProtectedRoute path="/parent/dashboard" role="parent" component={ParentDashboard} />
      <ProtectedRoute path="/parent/performance" role="parent" component={ParentPerformance} />
      <ProtectedRoute path="/parent/meetings" role="parent" component={ParentMeetings} />

      {/* Admin Routes */}
      <ProtectedRoute path="/admin/dashboard" role="admin" component={AdminDashboard} />
      <ProtectedRoute path="/admin/students" role="admin" component={AdminStudents} />
      <ProtectedRoute path="/admin/teachers" role="admin" component={AdminTeachers} />
      <ProtectedRoute path="/admin/settings" role="admin" component={AdminSettings} />

      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ThemeProvider attribute="class">
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </ThemeProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
