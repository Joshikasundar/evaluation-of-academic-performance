import { useAuth } from "@/hooks/use-auth";
import { UserRole } from "@shared/schema";
import { Loader2 } from "lucide-react";
import { Route, Redirect } from "wouter";

interface ProtectedRouteProps {
  path: string;
  role: UserRole;
  component: React.ComponentType;
}

export function ProtectedRoute({ 
  path, 
  role, 
  component: Component 
}: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();

  return (
    <Route path={path}>
      {() => {
        if (isLoading) {
          return (
            <div className="flex items-center justify-center min-h-screen">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          );
        }

        if (!user) {
          return <Redirect to="/auth" />;
        }

        if (user.role !== role) {
          const redirectPath = user.role === "student" 
            ? "/" 
            : `/${user.role}/dashboard`;
          return <Redirect to={redirectPath} />;
        }

        return <Component />;
      }}
    </Route>
  );
}
