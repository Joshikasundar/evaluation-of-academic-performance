import React from "react";
import Sidebar from "@/components/ui/sidebar";
import { Toaster } from "@/components/ui/toaster";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";

interface DashboardLayoutProps {
  children: React.ReactNode;
  pageTitle: string;
}

export function DashboardLayout({ children, pageTitle }: DashboardLayoutProps) {
  const { user, isLoading } = useAuth();

  // Redirect to login if not authenticated
  if (!isLoading && !user) {
    return <Redirect to="/auth" />;
  }

  // No need to show anything while loading
  if (isLoading) {
    return null;
  }

  // Choose a URL based on user role
  const homeUrl = user?.role === "student" 
    ? "/" 
    : `/${user?.role}/dashboard`;

  return (
    <div className="min-h-screen bg-slate-100">
      <Sidebar>{pageTitle}</Sidebar>
      
      <main className={cn("lg:ml-64 min-h-screen pt-0 lg:pt-0 transition-all duration-300")}>
        <div className="hidden lg:block bg-white shadow-sm py-4 px-6">
          <h1 className="text-xl font-medium">{pageTitle}</h1>
        </div>
        
        <div className="p-6">
          {children}
        </div>
      </main>
      
      <Toaster />
    </div>
  );
}
