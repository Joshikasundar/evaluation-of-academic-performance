import * as React from "react";
import { cn } from "@/lib/utils";

// Main chart container
interface ChartProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

export function Chart({ className, children, ...props }: ChartProps) {
  return (
    <div className={cn("space-y-4", className)} {...props}>
      {children}
    </div>
  );
}

// Chart container with specific dimensions
interface ChartContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

export function ChartContainer({ className, children, ...props }: ChartContainerProps) {
  return (
    <div className={cn("relative", className)} {...props}>
      {children}
    </div>
  );
}

// Chart content area where bars are rendered
interface ChartContentProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

export function ChartContent({ className, children, ...props }: ChartContentProps) {
  return (
    <div 
      className={cn("relative h-[240px] w-full flex items-end justify-around gap-2 p-6", className)} 
      {...props}
    >
      {children}
    </div>
  );
}

// Individual chart bar
interface ChartBarProps extends React.HTMLAttributes<HTMLDivElement> {
  value: number;
  name: string;
  color?: string;
}

export function ChartBar({ value, name, color = "var(--chart-1)", className, ...props }: ChartBarProps) {
  return (
    <div className="relative flex flex-col items-center justify-end group" {...props}>
      <div 
        className={cn("w-11 transition-all duration-300 rounded-t", className)}
        style={{ height: `${value}%`, backgroundColor: color }}
      />
      <span className="absolute bottom-0 left-0 right-0 whitespace-nowrap text-center text-xs font-medium transform translate-y-full mt-1 truncate px-1">{name}</span>
      
      {/* Tooltip */}
      <div className="absolute bottom-full mb-2 transform -translate-x-1/2 left-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
        <div className="bg-slate-800 text-white px-2 py-1 rounded text-xs whitespace-nowrap">
          {Math.round(value)}%
        </div>
        <div className="border-t-4 border-x-4 border-t-slate-800 border-x-transparent h-1 w-0 mx-auto" />
      </div>
    </div>
  );
}

// X-axis for chart
export function ChartAxisX({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div 
      className={cn("h-px w-full bg-border mt-2", className)} 
      {...props}
    />
  );
}

// Y-axis for chart
export function ChartAxisY({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div 
      className={cn("absolute bottom-6 left-6 top-6 w-px bg-border", className)} 
      {...props}
    />
  );
}

// Legend for the chart
export function ChartLegend({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div 
      className={cn("flex flex-wrap items-center justify-center gap-4 mt-2", className)} 
      {...props}
    />
  );
}

// Legend item
interface ChartLegendItemProps extends React.HTMLAttributes<HTMLDivElement> {
  color: string;
  name: string;
}

export function ChartLegendItem({ color, name, className, ...props }: ChartLegendItemProps) {
  return (
    <div className={cn("flex items-center gap-1", className)} {...props}>
      <div 
        className="h-2 w-2 rounded-full" 
        style={{ backgroundColor: color }}
      />
      <span className="text-xs font-medium">{name}</span>
    </div>
  );
}
