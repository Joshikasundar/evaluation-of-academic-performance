import * as React from "react";
import { cn } from "@/lib/utils";
import { Link, useLocation } from "wouter";
import { Button } from "./button";
import { Avatar, AvatarFallback } from "./avatar";
import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { NAVIGATION_LINKS } from "@/lib/constants";
import { getInitials } from "@/lib/utils";
import { Menu, LogOut, X, Home, BookOpen, Users, Calendar, AlertTriangle, FileText, BarChart } from "lucide-react";

interface SidebarProps {
  className?: string;
  children?: React.ReactNode;
}

export default function Sidebar({ className, children }: SidebarProps) {
  const [location] = useLocation();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { user, userDetails, logoutMutation } = useAuth();

  // Close sidebar on location change on mobile
  useEffect(() => {
    setIsMobileOpen(false);
  }, [location]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileOpen(false);
      }
    };

    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Show links based on user role
  const links = user?.role ? NAVIGATION_LINKS[user.role] : [];
  const roleName = user?.role 
    ? user.role.charAt(0).toUpperCase() + user.role.slice(1) 
    : "";

  const homePath = user?.role === "student" 
    ? "/" 
    : `/${user?.role}/dashboard`;

  return (
    <>
      {/* Mobile header */}
      <header className="bg-white shadow-sm py-4 px-6 flex items-center justify-between lg:hidden">
        <div className="flex items-center">
          <Button
            variant="ghost"
            size="icon"
            className="mr-4 text-slate-700"
            onClick={() => setIsMobileOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-medium">{children}</h1>
        </div>
        
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            className="text-slate-500 hover:text-slate-700"
            onClick={() => logoutMutation.mutate()}
          >
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </header>

      {/* Mobile sidebar overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsMobileOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <aside 
        className={cn(
          "fixed inset-y-0 left-0 w-64 bg-slate-800 text-white shadow-lg transform transition-transform duration-300 z-50",
          isMobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
          className
        )}
      >
        <div className="p-4 border-b border-slate-700">
          <div className="flex items-center justify-between">
            <Link href={homePath}>
              <h2 className="text-xl font-bold cursor-pointer">Academic System</h2>
            </Link>
            <Button 
              variant="ghost" 
              size="icon" 
              className="lg:hidden text-white" 
              onClick={() => setIsMobileOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        <div className="p-4 border-b border-slate-700">
          <div className="flex items-center space-x-3">
            <Avatar className="bg-primary">
              <AvatarFallback>
                {user?.name ? getInitials(user.name) : "U"}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-medium">{user?.name || "User"}</h3>
              <p className="text-sm text-slate-400">{roleName}</p>
            </div>
          </div>
        </div>
        
        <nav className="p-4 space-y-1">
          {links.map((link) => {
            const isActive = location === link.href;
            
            // Map icon string to the actual icon component
            let IconComponent;
            switch (link.icon) {
              case "Home": IconComponent = Home; break;
              case "BookOpen": IconComponent = BookOpen; break;
              case "Users": IconComponent = Users; break;
              case "Calendar": IconComponent = Calendar; break;
              case "AlertTriangle": IconComponent = AlertTriangle; break;
              case "FileText": IconComponent = FileText; break;
              case "BarChart": IconComponent = BarChart; break;
              default: IconComponent = Home;
            }
            
            return (
              <Link href={link.href} key={link.href}>
                <a
                  className={cn(
                    "flex items-center space-x-3 p-3 rounded-md",
                    isActive
                      ? "bg-slate-700"
                      : "hover:bg-slate-700 transition-colors"
                  )}
                >
                  <IconComponent className="w-5 h-5" />
                  <span>{link.label}</span>
                </a>
              </Link>
            );
          })}
          
          <Button
            variant="ghost"
            className="w-full justify-start text-white hover:bg-slate-700 mt-auto"
            onClick={() => logoutMutation.mutate()}
          >
            <LogOut className="mr-2 h-5 w-5" />
            <span>Logout</span>
          </Button>
        </nav>
      </aside>
    </>
  );
}
