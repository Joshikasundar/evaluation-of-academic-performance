import {
  User, InsertUser, Student, InsertStudent, Teacher, InsertTeacher, 
  Parent, InsertParent, Mark, InsertMark, Attendance, InsertAttendance,
  Announcement, InsertAnnouncement, Meeting, InsertMeeting, Subject,
  Class, InsertClass, UserWithDetails, StudentWithMarks, TeacherWithSubject,
  ParentWithStudent, MeetingWithDetails, AnnouncementWithCreator, UserRole,
  MarkWithSubject, AttendanceStatus
} from "@shared/schema";
import session from "express-session";

export interface IStorage {
  // Session store
  sessionStore: session.SessionStore;
  
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getUserWithDetails(id: number): Promise<UserWithDetails | undefined>;

  // Students
  getStudents(): Promise<StudentWithMarks[]>;
  getStudent(id: number): Promise<Student | undefined>;
  getStudentByUserId(userId: number): Promise<Student | undefined>;
  getStudentById(studentId: string): Promise<StudentWithMarks | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, student: Partial<Student>): Promise<Student | undefined>;
  deleteStudent(id: number): Promise<boolean>;

  // Teachers
  getTeachers(): Promise<TeacherWithSubject[]>;
  getTeacher(id: number): Promise<Teacher | undefined>;
  getTeacherByUserId(userId: number): Promise<Teacher | undefined>;
  createTeacher(teacher: InsertTeacher): Promise<Teacher>;
  updateTeacher(id: number, teacher: Partial<Teacher>): Promise<Teacher | undefined>;
  deleteTeacher(id: number): Promise<boolean>;

  // Parents
  getParents(): Promise<ParentWithStudent[]>;
  getParent(id: number): Promise<Parent | undefined>;
  getParentByUserId(userId: number): Promise<Parent | undefined>;
  createParent(parent: InsertParent): Promise<Parent>;
  updateParent(id: number, parent: Partial<Parent>): Promise<Parent | undefined>;
  deleteParent(id: number): Promise<boolean>;

  // Marks
  getMarksByStudent(studentId: number): Promise<MarkWithSubject[]>;
  getMarksBySubject(subjectId: number): Promise<Mark[]>;
  createMark(mark: InsertMark): Promise<Mark>;
  updateMark(id: number, mark: Partial<Mark>): Promise<Mark | undefined>;
  deleteMark(id: number): Promise<boolean>;

  // Attendance
  getAttendanceByStudent(studentId: number): Promise<Attendance[]>;
  getAttendanceByDate(date: Date): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendance: Partial<Attendance>): Promise<Attendance | undefined>;
  deleteAttendance(id: number): Promise<boolean>;

  // Announcements
  getAnnouncements(): Promise<Announcement[]>;
  getAnnouncement(id: number): Promise<Announcement | undefined>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  updateAnnouncement(id: number, announcement: Partial<Announcement>): Promise<Announcement | undefined>;
  deleteAnnouncement(id: number): Promise<boolean>;

  // Meetings
  getMeetings(): Promise<Meeting[]>;
  getMeetingsByTeacher(teacherId: number): Promise<MeetingWithDetails[]>;
  getMeetingsByStudent(studentId: number): Promise<MeetingWithDetails[]>;
  getMeeting(id: number): Promise<Meeting | undefined>;
  createMeeting(meeting: InsertMeeting): Promise<Meeting>;
  updateMeeting(id: number, meeting: Partial<Meeting>): Promise<Meeting | undefined>;
  deleteMeeting(id: number): Promise<boolean>;

  // Subjects
  getSubjects(): Promise<Subject[]>;
  getSubject(id: number): Promise<Subject | undefined>;

  // Classes
  getClasses(): Promise<Class[]>;
  getClass(id: number): Promise<Class | undefined>;
}

import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private students: Map<number, Student>;
  private teachers: Map<number, Teacher>;
  private parents: Map<number, Parent>;
  private marks: Map<number, Mark>;
  private attendance: Map<number, Attendance>;
  private announcements: Map<number, Announcement>;
  private meetings: Map<number, Meeting>;
  private subjects: Map<number, Subject>;
  private classes: Map<number, Class>;
  private nextId: { [key: string]: number };
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.students = new Map();
    this.teachers = new Map();
    this.parents = new Map();
    this.marks = new Map();
    this.attendance = new Map();
    this.announcements = new Map();
    this.meetings = new Map();
    this.subjects = new Map();
    this.classes = new Map();
    this.nextId = {
      users: 1,
      students: 1,
      teachers: 1,
      parents: 1,
      marks: 1,
      attendance: 1,
      announcements: 1,
      meetings: 1,
      subjects: 1,
      classes: 1,
    };
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });

    // Initialize with default subjects
    this.initializeSubjects();
    this.initializeClasses();
  }

  private initializeSubjects() {
    const subjects = [
      { id: 1, name: "Physics" },
      { id: 2, name: "Chemistry" },
      { id: 3, name: "Data Structures" },
      { id: 4, name: "BEEE" },
      { id: 5, name: "Mathematics" },
    ];
    
    subjects.forEach(subject => {
      this.subjects.set(subject.id, subject);
    });
    this.nextId.subjects = subjects.length + 1;
  }

  private initializeClasses() {
    const classes = [
      { id: 1, name: "10A" },
      { id: 2, name: "10B" },
      { id: 3, name: "11A" },
      { id: 4, name: "11B" },
    ];
    
    classes.forEach(cls => {
      this.classes.set(cls.id, cls);
    });
    this.nextId.classes = classes.length + 1;
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.nextId.users++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, update: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...update };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  async getUserWithDetails(id: number): Promise<UserWithDetails | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;

    const result: UserWithDetails = { ...user };

    if (user.role === "student") {
      result.student = await this.getStudentByUserId(id);
    } else if (user.role === "teacher") {
      result.teacher = await this.getTeacherByUserId(id);
    } else if (user.role === "parent") {
      result.parent = await this.getParentByUserId(id);
    }

    return result;
  }

  // Students
  async getStudents(): Promise<StudentWithMarks[]> {
    const students = Array.from(this.students.values());
    const results: StudentWithMarks[] = [];

    for (const student of students) {
      const user = await this.getUser(student.userId);
      if (!user) continue;

      const marks = await this.getMarksByStudent(student.id);
      const attendance = await this.getAttendanceByStudent(student.id);

      results.push({
        ...student,
        user,
        marks,
        attendance
      });
    }

    return results;
  }

  async getStudent(id: number): Promise<Student | undefined> {
    return this.students.get(id);
  }

  async getStudentByUserId(userId: number): Promise<Student | undefined> {
    return Array.from(this.students.values()).find(
      (student) => student.userId === userId,
    );
  }

  async getStudentById(studentId: string): Promise<StudentWithMarks | undefined> {
    const student = Array.from(this.students.values()).find(
      (student) => student.studentId === studentId,
    );
    
    if (!student) return undefined;

    const user = await this.getUser(student.userId);
    if (!user) return undefined;

    const marks = await this.getMarksByStudent(student.id);
    const attendance = await this.getAttendanceByStudent(student.id);

    return {
      ...student,
      user,
      marks,
      attendance
    };
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const id = this.nextId.students++;
    const student: Student = { ...insertStudent, id };
    this.students.set(id, student);
    return student;
  }

  async updateStudent(id: number, update: Partial<Student>): Promise<Student | undefined> {
    const student = this.students.get(id);
    if (!student) return undefined;
    
    const updatedStudent = { ...student, ...update };
    this.students.set(id, updatedStudent);
    return updatedStudent;
  }

  async deleteStudent(id: number): Promise<boolean> {
    return this.students.delete(id);
  }

  // Teachers
  async getTeachers(): Promise<TeacherWithSubject[]> {
    const teachers = Array.from(this.teachers.values());
    const results: TeacherWithSubject[] = [];

    for (const teacher of teachers) {
      const user = await this.getUser(teacher.userId);
      if (!user) continue;

      results.push({
        ...teacher,
        user
      });
    }

    return results;
  }

  async getTeacher(id: number): Promise<Teacher | undefined> {
    return this.teachers.get(id);
  }

  async getTeacherByUserId(userId: number): Promise<Teacher | undefined> {
    return Array.from(this.teachers.values()).find(
      (teacher) => teacher.userId === userId,
    );
  }

  async createTeacher(insertTeacher: InsertTeacher): Promise<Teacher> {
    const id = this.nextId.teachers++;
    const teacher: Teacher = { ...insertTeacher, id };
    this.teachers.set(id, teacher);
    return teacher;
  }

  async updateTeacher(id: number, update: Partial<Teacher>): Promise<Teacher | undefined> {
    const teacher = this.teachers.get(id);
    if (!teacher) return undefined;
    
    const updatedTeacher = { ...teacher, ...update };
    this.teachers.set(id, updatedTeacher);
    return updatedTeacher;
  }

  async deleteTeacher(id: number): Promise<boolean> {
    return this.teachers.delete(id);
  }

  // Parents
  async getParents(): Promise<ParentWithStudent[]> {
    const parents = Array.from(this.parents.values());
    const results: ParentWithStudent[] = [];

    for (const parent of parents) {
      const user = await this.getUser(parent.userId);
      if (!user) continue;

      const student = await this.getStudent(parent.studentId);
      if (!student) continue;

      const studentUser = await this.getUser(student.userId);
      if (!studentUser) continue;

      const marks = await this.getMarksByStudent(student.id);
      const attendance = await this.getAttendanceByStudent(student.id);

      results.push({
        ...parent,
        user,
        student: {
          ...student,
          user: studentUser,
          marks,
          attendance
        }
      });
    }

    return results;
  }

  async getParent(id: number): Promise<Parent | undefined> {
    return this.parents.get(id);
  }

  async getParentByUserId(userId: number): Promise<Parent | undefined> {
    return Array.from(this.parents.values()).find(
      (parent) => parent.userId === userId,
    );
  }

  async createParent(insertParent: InsertParent): Promise<Parent> {
    const id = this.nextId.parents++;
    const parent: Parent = { ...insertParent, id };
    this.parents.set(id, parent);
    return parent;
  }

  async updateParent(id: number, update: Partial<Parent>): Promise<Parent | undefined> {
    const parent = this.parents.get(id);
    if (!parent) return undefined;
    
    const updatedParent = { ...parent, ...update };
    this.parents.set(id, updatedParent);
    return updatedParent;
  }

  async deleteParent(id: number): Promise<boolean> {
    return this.parents.delete(id);
  }

  // Marks
  async getMarksByStudent(studentId: number): Promise<MarkWithSubject[]> {
    const studentMarks = Array.from(this.marks.values()).filter(
      (mark) => mark.studentId === studentId,
    );

    const marksWithSubjects: MarkWithSubject[] = [];
    
    for (const mark of studentMarks) {
      const subject = await this.getSubject(mark.subjectId);
      if (!subject) continue;
      
      marksWithSubjects.push({
        ...mark,
        subject
      });
    }
    
    return marksWithSubjects;
  }

  async getMarksBySubject(subjectId: number): Promise<Mark[]> {
    return Array.from(this.marks.values()).filter(
      (mark) => mark.subjectId === subjectId,
    );
  }

  async createMark(insertMark: InsertMark): Promise<Mark> {
    const id = this.nextId.marks++;
    const now = new Date();
    const mark: Mark = { 
      ...insertMark, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.marks.set(id, mark);
    return mark;
  }

  async updateMark(id: number, update: Partial<Mark>): Promise<Mark | undefined> {
    const mark = this.marks.get(id);
    if (!mark) return undefined;
    
    const updatedMark = { 
      ...mark, 
      ...update, 
      updatedAt: new Date() 
    };
    this.marks.set(id, updatedMark);
    return updatedMark;
  }

  async deleteMark(id: number): Promise<boolean> {
    return this.marks.delete(id);
  }

  // Attendance
  async getAttendanceByStudent(studentId: number): Promise<Attendance[]> {
    return Array.from(this.attendance.values()).filter(
      (attendance) => attendance.studentId === studentId,
    );
  }

  async getAttendanceByDate(date: Date): Promise<Attendance[]> {
    const dateString = date.toISOString().split('T')[0];
    return Array.from(this.attendance.values()).filter(
      (attendance) => {
        const attendanceDate = new Date(attendance.date);
        return attendanceDate.toISOString().split('T')[0] === dateString;
      }
    );
  }

  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const id = this.nextId.attendance++;
    const now = new Date();
    const attendance: Attendance = { 
      ...insertAttendance, 
      id, 
      createdAt: now
    };
    this.attendance.set(id, attendance);
    return attendance;
  }

  async updateAttendance(id: number, update: Partial<Attendance>): Promise<Attendance | undefined> {
    const attendance = this.attendance.get(id);
    if (!attendance) return undefined;
    
    const updatedAttendance = { 
      ...attendance, 
      ...update
    };
    this.attendance.set(id, updatedAttendance);
    return updatedAttendance;
  }

  async deleteAttendance(id: number): Promise<boolean> {
    return this.attendance.delete(id);
  }

  // Announcements
  async getAnnouncements(): Promise<Announcement[]> {
    return Array.from(this.announcements.values());
  }

  async getAnnouncement(id: number): Promise<Announcement | undefined> {
    return this.announcements.get(id);
  }

  async createAnnouncement(insertAnnouncement: InsertAnnouncement): Promise<Announcement> {
    const id = this.nextId.announcements++;
    const now = new Date();
    const announcement: Announcement = { 
      ...insertAnnouncement, 
      id, 
      createdAt: now
    };
    this.announcements.set(id, announcement);
    return announcement;
  }

  async updateAnnouncement(id: number, update: Partial<Announcement>): Promise<Announcement | undefined> {
    const announcement = this.announcements.get(id);
    if (!announcement) return undefined;
    
    const updatedAnnouncement = { 
      ...announcement, 
      ...update
    };
    this.announcements.set(id, updatedAnnouncement);
    return updatedAnnouncement;
  }

  async deleteAnnouncement(id: number): Promise<boolean> {
    return this.announcements.delete(id);
  }

  // Meetings
  async getMeetings(): Promise<Meeting[]> {
    return Array.from(this.meetings.values());
  }

  async getMeetingsByTeacher(teacherId: number): Promise<MeetingWithDetails[]> {
    const teacherMeetings = Array.from(this.meetings.values()).filter(
      (meeting) => meeting.teacherId === teacherId,
    );

    const result: MeetingWithDetails[] = [];

    for (const meeting of teacherMeetings) {
      const teacher = await this.getTeacher(meeting.teacherId);
      if (!teacher) continue;

      const teacherUser = await this.getUser(teacher.userId);
      if (!teacherUser) continue;

      const student = await this.getStudent(meeting.studentId);
      if (!student) continue;

      const studentUser = await this.getUser(student.userId);
      if (!studentUser) continue;

      const marks = await this.getMarksByStudent(student.id);
      const attendance = await this.getAttendanceByStudent(student.id);

      result.push({
        ...meeting,
        teacher: {
          ...teacher,
          user: teacherUser
        },
        student: {
          ...student,
          user: studentUser,
          marks,
          attendance
        }
      });
    }

    return result;
  }

  async getMeetingsByStudent(studentId: number): Promise<MeetingWithDetails[]> {
    const studentMeetings = Array.from(this.meetings.values()).filter(
      (meeting) => meeting.studentId === studentId,
    );

    const result: MeetingWithDetails[] = [];

    for (const meeting of studentMeetings) {
      const teacher = await this.getTeacher(meeting.teacherId);
      if (!teacher) continue;

      const teacherUser = await this.getUser(teacher.userId);
      if (!teacherUser) continue;

      const student = await this.getStudent(meeting.studentId);
      if (!student) continue;

      const studentUser = await this.getUser(student.userId);
      if (!studentUser) continue;

      const marks = await this.getMarksByStudent(student.id);
      const attendance = await this.getAttendanceByStudent(student.id);

      result.push({
        ...meeting,
        teacher: {
          ...teacher,
          user: teacherUser
        },
        student: {
          ...student,
          user: studentUser,
          marks,
          attendance
        }
      });
    }

    return result;
  }

  async getMeeting(id: number): Promise<Meeting | undefined> {
    return this.meetings.get(id);
  }

  async createMeeting(insertMeeting: InsertMeeting): Promise<Meeting> {
    const id = this.nextId.meetings++;
    const now = new Date();
    const meeting: Meeting = { 
      ...insertMeeting, 
      id, 
      createdAt: now
    };
    this.meetings.set(id, meeting);
    return meeting;
  }

  async updateMeeting(id: number, update: Partial<Meeting>): Promise<Meeting | undefined> {
    const meeting = this.meetings.get(id);
    if (!meeting) return undefined;
    
    const updatedMeeting = { 
      ...meeting, 
      ...update
    };
    this.meetings.set(id, updatedMeeting);
    return updatedMeeting;
  }

  async deleteMeeting(id: number): Promise<boolean> {
    return this.meetings.delete(id);
  }

  // Subjects
  async getSubjects(): Promise<Subject[]> {
    return Array.from(this.subjects.values());
  }

  async getSubject(id: number): Promise<Subject | undefined> {
    return this.subjects.get(id);
  }

  // Classes
  async getClasses(): Promise<Class[]> {
    return Array.from(this.classes.values());
  }

  async getClass(id: number): Promise<Class | undefined> {
    return this.classes.get(id);
  }
}

// Import DatabaseStorage
import { DatabaseStorage } from './db-storage';

// Use DatabaseStorage instead of MemStorage
export const storage = new DatabaseStorage();
