import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { 
  insertMarksSchema, 
  insertAttendanceSchema, 
  insertAnnouncementSchema, 
  insertMeetingSchema,
  insertStudentSchema,
  insertTeacherSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // API routes
  
  // Students routes
  // IMPORTANT: The order matters - specific routes must come first
  
  // Get student by user ID - this specific route must be before the general :id route
  app.get("/api/students/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const student = await storage.getStudentByUserId(userId);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student by user ID" });
    }
  });
  
  app.get("/api/students", async (req, res) => {
    try {
      const students = await storage.getStudents();
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.get("/api/students/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const student = await storage.getStudentById(id);
      
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student" });
    }
  });

  app.post("/api/students", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const studentData = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(studentData);
      res.status(201).json(student);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid student data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create student" });
    }
  });

  app.put("/api/students/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const student = await storage.getStudent(parseInt(id));
      
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      const updatedStudent = await storage.updateStudent(parseInt(id), req.body);
      res.json(updatedStudent);
    } catch (error) {
      res.status(500).json({ message: "Failed to update student" });
    }
  });

  app.delete("/api/students/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      console.log("Attempting to delete student with ID:", id);
      
      // First, get the student to make sure it exists
      const student = await storage.getStudent(parseInt(id));
      if (!student) {
        console.log("Student not found for deletion, ID:", id);
        return res.status(404).json({ message: "Student not found" });
      }
      
      // Get the student with full details to check relationships
      const studentDetails = await storage.getStudentById(student.studentId);
      if (!studentDetails) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      // Try to delete the student and all related records
      const deleted = await storage.deleteStudent(parseInt(id));
      
      if (!deleted) {
        console.log("Deletion returned false for student ID:", id);
        return res.status(400).json({ 
          message: "Could not delete student. This might be due to relationships with other records." 
        });
      }
      
      console.log("Successfully deleted student ID:", id);
      res.status(200).json({ message: "Student and all related records successfully deleted" });
    } catch (error) {
      console.error("Error in student deletion:", error);
      res.status(500).json({ 
        message: "An error occurred while deleting the student. Please try again."
      });
    }
  });

  // Teachers routes
  app.get("/api/teachers", async (req, res) => {
    try {
      const teachers = await storage.getTeachers();
      res.json(teachers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teachers" });
    }
  });

  app.post("/api/teachers", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const teacherData = insertTeacherSchema.parse(req.body);
      const teacher = await storage.createTeacher(teacherData);
      res.status(201).json(teacher);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid teacher data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create teacher" });
    }
  });

  app.put("/api/teachers/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const teacher = await storage.getTeacher(parseInt(id));
      
      if (!teacher) {
        return res.status(404).json({ message: "Teacher not found" });
      }
      
      const updatedTeacher = await storage.updateTeacher(parseInt(id), req.body);
      res.json(updatedTeacher);
    } catch (error) {
      res.status(500).json({ message: "Failed to update teacher" });
    }
  });

  app.delete("/api/teachers/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      console.log("Attempting to delete teacher with ID:", id);
      
      // First, get the teacher to make sure it exists
      const teacher = await storage.getTeacher(parseInt(id));
      if (!teacher) {
        console.log("Teacher not found for deletion, ID:", id);
        return res.status(404).json({ message: "Teacher not found" });
      }
      
      // Try to delete the teacher and all related records
      const deleted = await storage.deleteTeacher(parseInt(id));
      
      if (!deleted) {
        console.log("Deletion returned false for teacher ID:", id);
        return res.status(400).json({ 
          message: "Could not delete teacher. This might be due to relationships with other records." 
        });
      }
      
      console.log("Successfully deleted teacher ID:", id);
      res.status(200).json({ message: "Teacher and all related records successfully deleted" });
    } catch (error) {
      console.error("Error in teacher deletion:", error);
      res.status(500).json({ 
        message: "An error occurred while deleting the teacher. Please try again."
      });
    }
  });

  // Marks routes
  app.get("/api/students/:studentId/marks", async (req, res) => {
    try {
      const { studentId } = req.params;
      const student = await storage.getStudent(parseInt(studentId));
      
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      const marks = await storage.getMarksByStudent(parseInt(studentId));
      res.json(marks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch marks" });
    }
  });

  app.post("/api/marks", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "teacher") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const markData = insertMarksSchema.parse(req.body);
      const mark = await storage.createMark(markData);
      res.status(201).json(mark);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid mark data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create mark" });
    }
  });

  app.put("/api/marks/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "teacher") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const mark = await storage.updateMark(parseInt(id), req.body);
      
      if (!mark) {
        return res.status(404).json({ message: "Mark not found" });
      }
      
      res.json(mark);
    } catch (error) {
      res.status(500).json({ message: "Failed to update mark" });
    }
  });

  // Attendance routes
  app.get("/api/students/:studentId/attendance", async (req, res) => {
    try {
      const { studentId } = req.params;
      const student = await storage.getStudent(parseInt(studentId));
      
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      const attendance = await storage.getAttendanceByStudent(parseInt(studentId));
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance" });
    }
  });

  app.post("/api/attendance", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "teacher") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const attendanceData = insertAttendanceSchema.parse(req.body);
      const attendance = await storage.createAttendance(attendanceData);
      res.status(201).json(attendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid attendance data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create attendance" });
    }
  });

  app.put("/api/attendance/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "teacher") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const attendance = await storage.updateAttendance(parseInt(id), req.body);
      
      if (!attendance) {
        return res.status(404).json({ message: "Attendance record not found" });
      }
      
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Failed to update attendance" });
    }
  });

  // Announcements routes
  app.get("/api/announcements", async (req, res) => {
    try {
      const announcements = await storage.getAnnouncements();
      console.log("Fetched announcements:", announcements);
      res.json(announcements);
    } catch (error) {
      console.error("Error fetching announcements:", error);
      res.status(500).json({ message: "Failed to fetch announcements" });
    }
  });

  app.post("/api/announcements", async (req, res) => {
    try {
      console.log("Creating announcement, authenticated:", req.isAuthenticated(), "user:", req.user);
      if (!req.isAuthenticated() || (req.user?.role !== "teacher" && req.user?.role !== "admin")) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      console.log("Announcement request body:", req.body);
      const announcementData = insertAnnouncementSchema.parse(req.body);
      console.log("Parsed announcement data:", announcementData);
      const announcement = await storage.createAnnouncement(announcementData);
      console.log("Created announcement:", announcement);
      res.status(201).json(announcement);
    } catch (error) {
      console.error("Error creating announcement:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid announcement data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create announcement" });
    }
  });

  app.put("/api/announcements/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || (req.user?.role !== "teacher" && req.user?.role !== "admin")) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const announcement = await storage.updateAnnouncement(parseInt(id), req.body);
      
      if (!announcement) {
        return res.status(404).json({ message: "Announcement not found" });
      }
      
      res.json(announcement);
    } catch (error) {
      res.status(500).json({ message: "Failed to update announcement" });
    }
  });

  app.delete("/api/announcements/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || (req.user?.role !== "teacher" && req.user?.role !== "admin")) {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      console.log("Attempting to delete announcement with ID:", id);
      
      // First, get the announcement to make sure it exists
      const announcement = await storage.getAnnouncement(parseInt(id));
      if (!announcement) {
        console.log("Announcement not found for deletion, ID:", id);
        return res.status(404).json({ message: "Announcement not found" });
      }
      
      // Try to delete the announcement
      try {
        const deleted = await storage.deleteAnnouncement(parseInt(id));
        
        if (!deleted) {
          console.log("Deletion returned false for announcement ID:", id);
          return res.status(404).json({ message: "Announcement not found or couldn't be deleted" });
        }
        
        console.log("Successfully deleted announcement ID:", id);
        res.status(204).end();
      } catch (deleteError) {
        console.error("Error during announcement deletion:", deleteError);
        res.status(500).json({ 
          message: "Error deleting announcement. Try again later."
        });
      }
    } catch (error) {
      console.error("Outer error in announcement deletion:", error);
      res.status(500).json({ message: "Failed to delete announcement" });
    }
  });

  // Meetings routes
  app.get("/api/meetings", async (req, res) => {
    try {
      const meetings = await storage.getMeetings();
      res.json(meetings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch meetings" });
    }
  });

  app.get("/api/teachers/:teacherId/meetings", async (req, res) => {
    try {
      const { teacherId } = req.params;
      const meetings = await storage.getMeetingsByTeacher(parseInt(teacherId));
      res.json(meetings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch meetings" });
    }
  });

  app.get("/api/students/:studentId/meetings", async (req, res) => {
    try {
      const { studentId } = req.params;
      const meetings = await storage.getMeetingsByStudent(parseInt(studentId));
      res.json(meetings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch meetings" });
    }
  });

  app.post("/api/meetings", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "teacher") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const meetingData = insertMeetingSchema.parse(req.body);
      const meeting = await storage.createMeeting(meetingData);
      res.status(201).json(meeting);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid meeting data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create meeting" });
    }
  });

  app.put("/api/meetings/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "teacher") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const meeting = await storage.updateMeeting(parseInt(id), req.body);
      
      if (!meeting) {
        return res.status(404).json({ message: "Meeting not found" });
      }
      
      res.json(meeting);
    } catch (error) {
      res.status(500).json({ message: "Failed to update meeting" });
    }
  });

  app.delete("/api/meetings/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "teacher") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const deleted = await storage.deleteMeeting(parseInt(id));
      
      if (!deleted) {
        return res.status(404).json({ message: "Meeting not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete meeting" });
    }
  });

  // Subjects routes
  app.get("/api/subjects", async (req, res) => {
    try {
      const subjects = await storage.getSubjects();
      res.json(subjects);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subjects" });
    }
  });

  // Classes routes
  app.get("/api/classes", async (req, res) => {
    try {
      const classes = await storage.getClasses();
      res.json(classes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch classes" });
    }
  });
  
  // User routes
  app.put("/api/users/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(403).json({ message: "Unauthorized" });
      }

      const { id } = req.params;
      const user = await storage.updateUser(parseInt(id), req.body);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
