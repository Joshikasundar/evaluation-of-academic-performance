import { eq, and } from 'drizzle-orm';
import { db } from './db';
import {
  User, InsertUser, Student, InsertStudent, Teacher, InsertTeacher, 
  Parent, InsertParent, Mark, InsertMark, Attendance, InsertAttendance,
  Announcement, InsertAnnouncement, Meeting, InsertMeeting, Subject,
  Class, InsertClass, UserWithDetails, StudentWithMarks, TeacherWithSubject,
  ParentWithStudent, MeetingWithDetails, AnnouncementWithCreator, UserRole,
  MarkWithSubject, AttendanceStatus,
  users, students, teachers, parents, marks, attendance, announcements, meetings, subjects, classes
} from "@shared/schema";
import { IStorage } from './storage';
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from './db';

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ pool, createTableIfMissing: true });
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, update: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(update)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return !!result;
  }

  async getUserWithDetails(id: number): Promise<UserWithDetails | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;

    const result: UserWithDetails = { ...user };

    if (user.role === "student") {
      result.student = await this.getStudentByUserId(id);
    } else if (user.role === "teacher") {
      result.teacher = await this.getTeacherByUserId(id);
    } else if (user.role === "parent") {
      result.parent = await this.getParentByUserId(id);
    }

    return result;
  }

  // Students
  async getStudents(): Promise<StudentWithMarks[]> {
    const allStudents = await db.select().from(students);
    const results: StudentWithMarks[] = [];

    for (const student of allStudents) {
      const user = await this.getUser(student.userId);
      if (!user) continue;

      const studentMarks = await this.getMarksByStudent(student.id);
      const studentAttendance = await this.getAttendanceByStudent(student.id);

      results.push({
        ...student,
        user,
        marks: studentMarks,
        attendance: studentAttendance
      });
    }

    return results;
  }

  async getStudent(id: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student;
  }

  async getStudentByUserId(userId: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.userId, userId));
    return student;
  }

  async getStudentById(studentId: string): Promise<StudentWithMarks | undefined> {
    const [student] = await db.select().from(students).where(eq(students.studentId, studentId));
    if (!student) return undefined;

    const user = await this.getUser(student.userId);
    if (!user) return undefined;

    const studentMarks = await this.getMarksByStudent(student.id);
    const studentAttendance = await this.getAttendanceByStudent(student.id);

    return {
      ...student,
      user,
      marks: studentMarks,
      attendance: studentAttendance
    };
  }

  async createStudent(insertStudent: InsertStudent): Promise<Student> {
    const [student] = await db.insert(students).values(insertStudent).returning();
    return student;
  }

  async updateStudent(id: number, update: Partial<Student>): Promise<Student | undefined> {
    const [updatedStudent] = await db
      .update(students)
      .set(update)
      .where(eq(students.id, id))
      .returning();
    return updatedStudent;
  }

  async deleteStudent(id: number): Promise<boolean> {
    try {
      // Get the student to find userId
      const student = await this.getStudent(id);
      if (!student) return false;
      
      // First delete related marks
      await db.delete(marks).where(eq(marks.studentId, id));
      
      // Delete related attendance records
      await db.delete(attendance).where(eq(attendance.studentId, id));
      
      // Delete related meetings
      await db.delete(meetings).where(eq(meetings.studentId, id));
      
      // Now delete the student record
      await db.delete(students).where(eq(students.id, id));
      
      // Finally delete the user account
      await db.delete(users).where(eq(users.id, student.userId));
      
      return true;
    } catch (error) {
      console.error("Error during student deletion:", error);
      return false;
    }
  }

  // Teachers
  async getTeachers(): Promise<TeacherWithSubject[]> {
    const allTeachers = await db.select().from(teachers);
    const results: TeacherWithSubject[] = [];

    for (const teacher of allTeachers) {
      const user = await this.getUser(teacher.userId);
      if (!user) continue;

      results.push({
        ...teacher,
        user
      });
    }

    return results;
  }

  async getTeacher(id: number): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.id, id));
    return teacher;
  }

  async getTeacherByUserId(userId: number): Promise<Teacher | undefined> {
    const [teacher] = await db.select().from(teachers).where(eq(teachers.userId, userId));
    return teacher;
  }

  async createTeacher(insertTeacher: InsertTeacher): Promise<Teacher> {
    const [teacher] = await db.insert(teachers).values(insertTeacher).returning();
    return teacher;
  }

  async updateTeacher(id: number, update: Partial<Teacher>): Promise<Teacher | undefined> {
    const [updatedTeacher] = await db
      .update(teachers)
      .set(update)
      .where(eq(teachers.id, id))
      .returning();
    return updatedTeacher;
  }

  async deleteTeacher(id: number): Promise<boolean> {
    try {
      // Get the teacher to find userId
      const teacher = await this.getTeacher(id);
      if (!teacher) return false;
      
      // Delete related meetings
      await db.delete(meetings).where(eq(meetings.teacherId, id));
      
      // Now delete the teacher record
      await db.delete(teachers).where(eq(teachers.id, id));
      
      // Finally delete the user account
      await db.delete(users).where(eq(users.id, teacher.userId));
      
      return true;
    } catch (error) {
      console.error("Error during teacher deletion:", error);
      return false;
    }
  }

  // Parents
  async getParents(): Promise<ParentWithStudent[]> {
    const allParents = await db.select().from(parents);
    const results: ParentWithStudent[] = [];

    for (const parent of allParents) {
      const user = await this.getUser(parent.userId);
      if (!user) continue;

      const student = await this.getStudent(parent.studentId);
      if (!student) continue;

      const studentUser = await this.getUser(student.userId);
      if (!studentUser) continue;

      const studentMarks = await this.getMarksByStudent(student.id);
      const studentAttendance = await this.getAttendanceByStudent(student.id);

      results.push({
        ...parent,
        user,
        student: {
          ...student,
          user: studentUser,
          marks: studentMarks,
          attendance: studentAttendance
        }
      });
    }

    return results;
  }

  async getParent(id: number): Promise<Parent | undefined> {
    const [parent] = await db.select().from(parents).where(eq(parents.id, id));
    return parent;
  }

  async getParentByUserId(userId: number): Promise<Parent | undefined> {
    const [parent] = await db.select().from(parents).where(eq(parents.userId, userId));
    return parent;
  }

  async createParent(insertParent: InsertParent): Promise<Parent> {
    const [parent] = await db.insert(parents).values(insertParent).returning();
    return parent;
  }

  async updateParent(id: number, update: Partial<Parent>): Promise<Parent | undefined> {
    const [updatedParent] = await db
      .update(parents)
      .set(update)
      .where(eq(parents.id, id))
      .returning();
    return updatedParent;
  }

  async deleteParent(id: number): Promise<boolean> {
    const result = await db.delete(parents).where(eq(parents.id, id));
    return !!result;
  }

  // Marks
  async getMarksByStudent(studentId: number): Promise<MarkWithSubject[]> {
    const studentMarks = await db.select().from(marks).where(eq(marks.studentId, studentId));
    const marksWithSubjects: MarkWithSubject[] = [];

    for (const mark of studentMarks) {
      const subject = await this.getSubject(mark.subjectId);
      if (!subject) continue;

      marksWithSubjects.push({
        ...mark,
        subject
      });
    }

    return marksWithSubjects;
  }

  async getMarksBySubject(subjectId: number): Promise<Mark[]> {
    return await db.select().from(marks).where(eq(marks.subjectId, subjectId));
  }

  async createMark(insertMark: InsertMark): Promise<Mark> {
    const now = new Date();
    const markToInsert = {
      ...insertMark,
      createdAt: now,
      updatedAt: now
    };
    
    const [mark] = await db.insert(marks).values(markToInsert).returning();
    return mark;
  }

  async updateMark(id: number, update: Partial<Mark>): Promise<Mark | undefined> {
    const updateWithTimestamp = {
      ...update,
      updatedAt: new Date()
    };
    
    const [updatedMark] = await db
      .update(marks)
      .set(updateWithTimestamp)
      .where(eq(marks.id, id))
      .returning();
    return updatedMark;
  }

  async deleteMark(id: number): Promise<boolean> {
    const result = await db.delete(marks).where(eq(marks.id, id));
    return !!result;
  }

  // Attendance
  async getAttendanceByStudent(studentId: number): Promise<Attendance[]> {
    return await db.select().from(attendance).where(eq(attendance.studentId, studentId));
  }

  async getAttendanceByDate(date: Date): Promise<Attendance[]> {
    const dateString = date.toISOString().split('T')[0];
    // Need to convert to string format for comparison
    // This is a simplified implementation - for more accurate date comparison use SQL functions
    const attendanceRecords = await db.select().from(attendance);
    return attendanceRecords.filter(a => {
      const attendanceDate = new Date(a.date);
      return attendanceDate.toISOString().split('T')[0] === dateString;
    });
  }

  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const now = new Date();
    const attendanceToInsert = {
      ...insertAttendance,
      createdAt: now
    };
    
    const [attendanceRecord] = await db.insert(attendance).values(attendanceToInsert).returning();
    return attendanceRecord;
  }

  async updateAttendance(id: number, update: Partial<Attendance>): Promise<Attendance | undefined> {
    const [updatedAttendance] = await db
      .update(attendance)
      .set(update)
      .where(eq(attendance.id, id))
      .returning();
    return updatedAttendance;
  }

  async deleteAttendance(id: number): Promise<boolean> {
    const result = await db.delete(attendance).where(eq(attendance.id, id));
    return !!result;
  }

  // Announcements
  async getAnnouncements(): Promise<Announcement[]> {
    const result = await db.select().from(announcements);
    console.log("Fetched announcements from database:", result);
    return result;
  }

  async getAnnouncement(id: number): Promise<Announcement | undefined> {
    const [announcement] = await db.select().from(announcements).where(eq(announcements.id, id));
    return announcement;
  }

  async createAnnouncement(insertAnnouncement: InsertAnnouncement): Promise<Announcement> {
    console.log("Creating announcement with data:", insertAnnouncement);
    try {
      const now = new Date();
      const announcementToInsert = {
        ...insertAnnouncement,
        createdAt: now
      };
      
      console.log("Prepared announcement insert:", announcementToInsert);
      const [announcement] = await db.insert(announcements).values(announcementToInsert).returning();
      console.log("Successfully created announcement:", announcement);
      return announcement;
    } catch (error) {
      console.error("Error creating announcement:", error);
      throw error;
    }
  }

  async updateAnnouncement(id: number, update: Partial<Announcement>): Promise<Announcement | undefined> {
    const [updatedAnnouncement] = await db
      .update(announcements)
      .set(update)
      .where(eq(announcements.id, id))
      .returning();
    return updatedAnnouncement;
  }

  async deleteAnnouncement(id: number): Promise<boolean> {
    const result = await db.delete(announcements).where(eq(announcements.id, id));
    return !!result;
  }

  // Meetings
  async getMeetings(): Promise<Meeting[]> {
    return await db.select().from(meetings);
  }

  async getMeetingsByTeacher(teacherId: number): Promise<MeetingWithDetails[]> {
    const teacherMeetings = await db.select().from(meetings).where(eq(meetings.teacherId, teacherId));
    const meetingsWithDetails: MeetingWithDetails[] = [];

    for (const meeting of teacherMeetings) {
      const teacher = await this.getTeacher(meeting.teacherId);
      if (!teacher) continue;

      const teacherUser = await this.getUser(teacher.userId);
      if (!teacherUser) continue;

      const student = await this.getStudent(meeting.studentId);
      if (!student) continue;

      const studentUser = await this.getUser(student.userId);
      if (!studentUser) continue;

      const studentMarks = await this.getMarksByStudent(student.id);
      const studentAttendance = await this.getAttendanceByStudent(student.id);

      meetingsWithDetails.push({
        ...meeting,
        teacher: {
          ...teacher,
          user: teacherUser
        },
        student: {
          ...student,
          user: studentUser,
          marks: studentMarks,
          attendance: studentAttendance
        }
      });
    }

    return meetingsWithDetails;
  }

  async getMeetingsByStudent(studentId: number): Promise<MeetingWithDetails[]> {
    const studentMeetings = await db.select().from(meetings).where(eq(meetings.studentId, studentId));
    const meetingsWithDetails: MeetingWithDetails[] = [];

    for (const meeting of studentMeetings) {
      const teacher = await this.getTeacher(meeting.teacherId);
      if (!teacher) continue;

      const teacherUser = await this.getUser(teacher.userId);
      if (!teacherUser) continue;

      const student = await this.getStudent(meeting.studentId);
      if (!student) continue;

      const studentUser = await this.getUser(student.userId);
      if (!studentUser) continue;

      const studentMarks = await this.getMarksByStudent(student.id);
      const studentAttendance = await this.getAttendanceByStudent(student.id);

      meetingsWithDetails.push({
        ...meeting,
        teacher: {
          ...teacher,
          user: teacherUser
        },
        student: {
          ...student,
          user: studentUser,
          marks: studentMarks,
          attendance: studentAttendance
        }
      });
    }

    return meetingsWithDetails;
  }

  async getMeeting(id: number): Promise<Meeting | undefined> {
    const [meeting] = await db.select().from(meetings).where(eq(meetings.id, id));
    return meeting;
  }

  async createMeeting(insertMeeting: InsertMeeting): Promise<Meeting> {
    const [meeting] = await db.insert(meetings).values(insertMeeting).returning();
    return meeting;
  }

  async updateMeeting(id: number, update: Partial<Meeting>): Promise<Meeting | undefined> {
    const [updatedMeeting] = await db
      .update(meetings)
      .set(update)
      .where(eq(meetings.id, id))
      .returning();
    return updatedMeeting;
  }

  async deleteMeeting(id: number): Promise<boolean> {
    const result = await db.delete(meetings).where(eq(meetings.id, id));
    return !!result;
  }

  // Subjects
  async getSubjects(): Promise<Subject[]> {
    return await db.select().from(subjects);
  }

  async getSubject(id: number): Promise<Subject | undefined> {
    const [subject] = await db.select().from(subjects).where(eq(subjects.id, id));
    return subject;
  }

  // Classes
  async getClasses(): Promise<Class[]> {
    return await db.select().from(classes);
  }

  async getClass(id: number): Promise<Class | undefined> {
    const [classRecord] = await db.select().from(classes).where(eq(classes.id, id));
    return classRecord;
  }
}