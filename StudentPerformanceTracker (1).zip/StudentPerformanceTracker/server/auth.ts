import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import createMemoryStore from "memorystore";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User, insertUserSchema, UserRole } from "@shared/schema";
import { z } from "zod";

declare global {
  namespace Express {
    interface User extends User {}
  }
}

const MemoryStore = createMemoryStore(session);
const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Initialize the database with default users for each role
async function initializeDefaultUsers() {
  // Check if we already have users
  const existingUsers = await Promise.all([
    storage.getUserByUsername("student"),
    storage.getUserByUsername("teacher"),
    storage.getUserByUsername("parent"),
    storage.getUserByUsername("admin")
  ]);

  // If any user already exists, we've already initialized
  if (existingUsers.some(user => user !== undefined)) {
    return;
  }

  // Create default users
  const defaultUsers = [
    {
      username: "student",
      password: await hashPassword("stud123"),
      name: "John Doe",
      role: "student" as UserRole,
      email: "john.doe@example.com"
    },
    {
      username: "teacher",
      password: await hashPassword("teach123"),
      name: "Ms. Smith",
      role: "teacher" as UserRole,
      email: "smith@example.com"
    },
    {
      username: "parent",
      password: await hashPassword("par123"),
      name: "Mr. Johnson",
      role: "parent" as UserRole,
      email: "johnson@example.com"
    },
    {
      username: "admin",
      password: await hashPassword("admin123"),
      name: "Admin User",
      role: "admin" as UserRole,
      email: "admin@example.com"
    }
  ];

  // Create users
  const createdUsers = await Promise.all(
    defaultUsers.map(async (userData) => {
      const user = await storage.createUser(userData);
      return { user, data: userData };
    })
  );

  // Create student for the student user
  const studentUser = createdUsers.find(({ data }) => data.role === "student");
  if (studentUser) {
    const student = await storage.createStudent({
      userId: studentUser.user.id,
      studentId: "ST001",
      classId: 1
    });

    // Create default marks for the student
    const subjects = await storage.getSubjects();
    const subjectMarks = [
      { subjectId: 1, marks: 92, maxMarks: 100, assignmentMarks: 90 }, // Physics
      { subjectId: 2, marks: 85, maxMarks: 100, assignmentMarks: 88 }, // Chemistry
      { subjectId: 3, marks: 78, maxMarks: 100, assignmentMarks: 80 }, // Data Structures
      { subjectId: 4, marks: 65, maxMarks: 100, assignmentMarks: 70 }, // BEEE
      { subjectId: 5, marks: 88, maxMarks: 100, assignmentMarks: 85 }  // Mathematics
    ];

    // Create teacher for the teacher user
    const teacherUser = createdUsers.find(({ data }) => data.role === "teacher");
    if (teacherUser) {
      const teacher = await storage.createTeacher({
        userId: teacherUser.user.id,
        teacherId: "T001",
        subject: "Physics"
      });

      // Create marks and attendance using teacher as creator
      for (const markData of subjectMarks) {
        await storage.createMark({
          studentId: student.id,
          ...markData,
          createdBy: teacherUser.user.id
        });
      }

      // Create attendance records
      const today = new Date();
      const attendanceData = [
        { 
          date: new Date(new Date().setDate(today.getDate() - 3)).toISOString().split('T')[0], 
          status: "present" as const 
        },
        { 
          date: new Date(new Date().setDate(today.getDate() - 2)).toISOString().split('T')[0], 
          status: "absent" as const 
        },
        { 
          date: new Date(new Date().setDate(today.getDate() - 1)).toISOString().split('T')[0], 
          status: "od" as const 
        },
        { 
          date: new Date().toISOString().split('T')[0], 
          status: "present" as const 
        }
      ];

      for (const data of attendanceData) {
        await storage.createAttendance({
          studentId: student.id,
          ...data,
          createdBy: teacherUser.user.id
        });
      }

      // Create parent for the parent user
      const parentUser = createdUsers.find(({ data }) => data.role === "parent");
      if (parentUser) {
        await storage.createParent({
          userId: parentUser.user.id,
          studentId: student.id
        });

        // Create a parent-teacher meeting
        const meetingDate = new Date();
        meetingDate.setDate(meetingDate.getDate() + 5);
        const formattedMeetingDate = meetingDate.toISOString().split('T')[0];

        await storage.createMeeting({
          teacherId: teacher.id,
          studentId: student.id,
          meetingDate: formattedMeetingDate,
          startTime: "10:00 AM",
          endTime: "10:30 AM",
          createdBy: teacherUser.user.id
        });
      }

      // Create announcements
      await storage.createAnnouncement({
        title: "Assignment Submission",
        content: "Physics assignment due on September 25th. Submit via online portal.",
        createdBy: teacherUser.user.id,
        classId: 1
      });

      await storage.createAnnouncement({
        title: "Mid-Term Exam Schedule",
        content: "Mid-term exams will start from October 10th. Syllabus available on the portal.",
        createdBy: teacherUser.user.id,
        classId: 1
      });
    }
  }
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "academic-performance-secret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  };

  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => {
    done(null, user.id);
  });
  
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Hash the password before storing
      userData.password = await hashPassword(userData.password);
      
      const user = await storage.createUser(userData);
      
      // Create role-specific entry based on user role
      if (userData.role === "student") {
        if (!req.body.studentId) {
          return res.status(400).json({ message: "Student ID is required" });
        }
        
        await storage.createStudent({
          userId: user.id,
          studentId: req.body.studentId,
          classId: req.body.classId
        });
      } else if (userData.role === "teacher") {
        if (!req.body.teacherId) {
          return res.status(400).json({ message: "Teacher ID is required" });
        }
        
        await storage.createTeacher({
          userId: user.id,
          teacherId: req.body.teacherId,
          subject: req.body.subject
        });
      } else if (userData.role === "parent") {
        if (!req.body.studentId) {
          return res.status(400).json({ message: "Student ID is required" });
        }
        
        // First try to find by database ID
        let student = await storage.getStudent(parseInt(req.body.studentId));
        
        // If not found, try by student ID string
        if (!student) {
          const students = await storage.getStudents();
          student = students.find(s => s.studentId === req.body.studentId);
        }
        
        if (!student) {
          return res.status(400).json({ message: "Student not found" });
        }
        
        await storage.createParent({
          userId: user.id,
          studentId: student.id
        });
      } else if (userData.role === "admin") {
        // No additional data needed for admin registration
        console.log("Admin user created:", user.id);
      }

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      next(error);
    }
  });

  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json(req.user);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });

  // Initialize default users
  initializeDefaultUsers().catch(console.error);
}
